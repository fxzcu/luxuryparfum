const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const { chromium } = require(process.env.PLAYWRIGHT_PACKAGE || 'playwright');

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const base = process.env.BASE_URL || 'http://127.0.0.1:3000';
  await fs.mkdir('.checks', { recursive: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  try {
    await page.goto(base, { waitUntil: 'networkidle' });
    assert.match(await page.locator('.announcement-bar').innerText(), /14 Y 18 DÍAS/i);
    assert.equal(await page.locator('.supplier-offer-card').count(), 3);
    const titles = await page.locator('.supplier-offer-card h3').allTextContents();
    assert(titles.includes('Proveedor de tecnología'));
    assert(titles.includes('Proveedor de perfumes'));
    assert(titles.includes('Proveedor de perfumes al por mayor'));
    for (const [category, amount] of [['technology', '$11.990'], ['perfume', '$10.990'], ['wholesale', '$12.990']]) {
      assert.equal((await page.locator(`.supplier-offer-${category} .supplier-offer-price strong`).innerText()).trim(), amount);
    }
    assert.equal(await page.locator('.supplier-bundle-card').count(), 1);
    assert.match(await page.locator('.supplier-bundle-card h3').innerText(), /Pack de los 3 proveedores/);
    assert.match(await page.locator('.bundle-total-price').innerText(), /19\.990/);
    assert.match(await page.locator('.bundle-saving-badge').innerText(), /15\.980/);
    assert.equal(await page.locator('.supplier-bundle-contents li').count(), 3);
    assert.match(await page.locator('.product-image.original-perfume-photo').first().getAttribute('src'), /^\/images\/products\//);
    await page.screenshot({ path: '.checks/home-desktop.png' });
    await page.locator('#proveedores').scrollIntoViewIfNeeded();
    await page.locator('#proveedores').screenshot({ path: '.checks/proveedores-desktop.png' });
    await page.locator('.supplier-offer-card').first().getByRole('button', { name: 'Comprar contacto' }).click();
    const dialog = page.getByRole('dialog');
    assert.equal(await dialog.locator('#contact-payment, select[name="paymentProvider"], input[type="radio"][name="paymentProvider"]').count(), 0);
    assert(!/Mercado Pago/i.test(await dialog.innerText()));
    if (await dialog.locator('.webpay-payment-method').count()) assert.match(await dialog.locator('.webpay-payment-method').innerText(), /Webpay Plus/);
    await dialog.getByLabel('Nombre y apellido').fill('Revisión visual sin envío');
    await dialog.locator('#contact-email').fill('visual-check@example.invalid');
    await dialog.getByRole('radio', { name: /TikTok/ }).check();
    assert(await dialog.getByLabel('Tu usuario de TikTok').isVisible());
    assert.equal(await dialog.locator('form').evaluate((form) => form.checkValidity()), false);
    await dialog.getByLabel('Tu usuario de TikTok').fill('@test_shop.cl');
    assert.equal(await dialog.locator('form').evaluate((form) => form.checkValidity()), true);
    await dialog.screenshot({ path: '.checks/contact-modal.png' });
    await page.keyboard.press('Escape');
    assert.equal(await page.getByRole('dialog').count(), 0);

    await page.getByRole('button', { name: 'Comprar pack' }).click();
    assert.match(await page.getByRole('dialog').locator('.contact-modal-summary').innerText(), /3 contactos digitales/);
    assert.match(await page.getByRole('dialog').locator('.contact-modal-summary').innerText(), /19\.990/);
    assert.equal(await page.getByRole('dialog').locator('.contact-pack-summary li').count(), 3);
    assert.equal(await page.getByRole('dialog').locator('#contact-payment, select[name="paymentProvider"], input[type="radio"][name="paymentProvider"]').count(), 0);
    assert(!/Mercado Pago/i.test(await page.getByRole('dialog').innerText()));
    await page.getByRole('dialog').getByRole('radio', { name: /TikTok/ }).check();
    assert(await page.getByRole('dialog').getByLabel('Tu usuario de TikTok').isVisible());
    await page.getByRole('button', { name: 'Cerrar compra de contacto' }).click();

    await page.locator('.featured-grid .product-card').first().getByRole('button', { name: 'Añadir', exact: true }).click();
    await page.getByRole('button', { name: /Abrir bolsa/ }).click();
    assert.match(await page.locator('.cart-drawer').innerText(), /14 y 18 días/);
    await page.getByRole('button', { name: /Continuar al pago/ }).click();
    assert.match(await page.locator('.checkout-form').innerText(), /Entrega entre 14 y 18 días/);
    assert.equal(await page.locator('.checkout-form .webpay-payment-method').count(), 1);
    assert.match(await page.locator('.checkout-form .webpay-payment-method').innerText(), /Webpay Plus.*Transbank/);
    assert.equal(await page.locator('.checkout-form select[name="paymentProvider"], .checkout-form input[type="radio"][name="paymentProvider"]').count(), 0);
    assert(!/Mercado Pago/i.test(await page.locator('.checkout-form').innerText()));
    assert(await page.locator('.checkout-form').getByRole('button', { name: /Pagar con Webpay/ }).isVisible());
    await page.getByRole('button', { name: 'Cerrar bolsa' }).click();
    const productUrl = await page.locator('.featured-grid .product-title').first().getAttribute('href');
    await page.goto(base + productUrl, { waitUntil: 'networkidle' });
    assert.match(await page.locator('.detail-copy').innerText(), /14 y 18 días/);
    assert(await page.locator('.detail-image-frame .original-perfume-photo').isVisible());

    const mobile = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 1 });
    mobile.on('pageerror', (error) => errors.push(error.message));
    await mobile.goto(base, { waitUntil: 'networkidle' });
    assert(await mobile.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), 'Mobile layout must not overflow horizontally.');
    await mobile.locator('#proveedores').scrollIntoViewIfNeeded();
    await mobile.locator('#proveedores').screenshot({ path: '.checks/proveedores-mobile.png' });
    await mobile.getByRole('button', { name: 'Comprar pack' }).click();
    assert.equal(await mobile.getByRole('dialog').locator('.contact-pack-summary li').count(), 3);
    assert.match(await mobile.getByRole('dialog').locator('.contact-modal-summary').innerText(), /19\.990/);
    assert(await mobile.getByRole('dialog').isVisible());
    assert(await mobile.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1));
    await mobile.getByRole('button', { name: 'Cerrar compra de contacto' }).click();
    await mobile.locator('.featured-grid .product-card').first().getByRole('button', { name: 'Añadir', exact: true }).click();
    await mobile.getByRole('button', { name: /Abrir bolsa/ }).click();
    await mobile.getByRole('button', { name: /Continuar al pago/ }).click();
    assert.match(await mobile.locator('.checkout-form .webpay-payment-method').innerText(), /Webpay Plus/);
    assert(!/Mercado Pago/i.test(await mobile.locator('.checkout-form').innerText()));
    assert(await mobile.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1));
    await mobile.getByRole('button', { name: 'Cerrar bolsa' }).click();
    await mobile.goto(base + '/admin', { waitUntil: 'networkidle' });
    assert(await mobile.getByRole('button', { name: /Ingresar al panel/ }).isVisible());
    assert.equal((await page.request.get(base + '/api/admin/suppliers')).status(), 401);
    assert.equal((await page.request.get(base + '/api/health')).status(), 200);
    assert.deepEqual(errors, []);
    console.log('PASS: original product photos, three supplier cards, exact prices, three-contact pack, email/TikTok form, Webpay-only checkout, shipping notices, product details, cart and responsive layout.');
    console.log('PASS: protected admin and health endpoint. No client runtime errors; no purchase or email submitted.');
  } finally {
    await browser.close();
  }
})().catch((error) => { console.error(error); process.exitCode = 1; });
