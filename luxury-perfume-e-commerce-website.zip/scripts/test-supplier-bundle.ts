import "dotenv/config";
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { eq, inArray } from "drizzle-orm";
import { NextRequest } from "next/server";
import { db, pool } from "@/db";
import { customers, orders, products, suppliers } from "@/db/schema";
import { getPublicSupplierOffers } from "@/lib/suppliers";
import { POST as purchase } from "@/app/api/suppliers/purchase/route";
import { sendConfirmationEmail } from "@/lib/orders";
import { normalizeSupplierInput, validateSupplierBundle } from "@/lib/supplier-input";

// Network is fully intercepted below. Test orders are temporary and never represent real payments.
const marker = `bundle-test-${randomBytes(5).toString("hex")}`;
const email = `${marker}@example.invalid`;
const fixtureIds: number[] = [];
const originalFetch = globalThis.fetch;
const envKeys = ["TRANSBANK_COMMERCE_CODE", "TRANSBANK_API_KEY", "TRANSBANK_ENV", "RESEND_API_KEY", "RESEND_FROM_EMAIL"];
const previousEnv = new Map(envKeys.map((key) => [key, process.env[key]]));
const request = (body: Record<string, unknown>) => new NextRequest("https://store.example/api/suppliers/purchase", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });

async function run() {
  const published = await getPublicSupplierOffers();
  for (const [category, price] of [["technology", 11990], ["perfume", 10990], ["wholesale", 12990], ["bundle", 19990]] as const) {
    assert.equal(published.find((offer) => offer.category === category)?.price, price);
  }
  const publishedPack = published.find((offer) => offer.category === "bundle")!;
  assert.equal(publishedPack.includedSuppliers.length, 3);
  assert.equal(publishedPack.individualTotal, 35970);
  assert.equal(publishedPack.individualTotal! - publishedPack.price!, 15980);
  console.log("PASS: requested prices and pack savings are persisted correctly.");

  const stockBefore = await db.select({ id: products.id, stock: products.stock }).from(products);
  const categories = ["technology", "perfume", "wholesale"];
  const members = await db.insert(suppliers).values(categories.map((category, index) => ({
    name: `TEST ONLY ${marker} ${category}`, category,
    description: "Temporary bundle integration-test fixture, removed on completion.",
    price: [11990, 10990, 12990][index], contact: `PRIVATE-${marker}-${category}`, active: true,
  }))).returning();
  fixtureIds.push(...members.map((member) => member.id));
  const [bundle] = await db.insert(suppliers).values({
    name: `TEST ONLY pack ${marker}`, category: "bundle", description: "Temporary bundle fixture.",
    price: 19990, contact: "NEVER-SEND-PACK-PLACEHOLDER", bundleSupplierIds: members.map((member) => member.id), active: true,
  }).returning();
  fixtureIds.push(bundle.id);

  assert.equal(await validateSupplierBundle("bundle", members.map((member) => member.id)), true);
  assert.equal(await validateSupplierBundle("bundle", [members[0].id, members[0].id, members[2].id]), false);
  assert.equal(normalizeSupplierInput({ category: "bundle", bundleSupplierIds: [members[0].id, members[0].id, members[2].id] }, bundle), null);
  const visible = await getPublicSupplierOffers();
  const visibleBundle = visible.find((offer) => offer.id === bundle.id)!;
  assert.equal(visibleBundle.canPurchase, true);
  assert.equal(visibleBundle.individualTotal, 35970);
  assert(!JSON.stringify(visible).includes(`PRIVATE-${marker}`));
  assert(!JSON.stringify(visible).includes("NEVER-SEND-PACK-PLACEHOLDER"));
  console.log("PASS: bundle membership is validated and private contacts are not exposed.");

  const base = { supplierId: bundle.id, name: `TEST ONLY ${marker}`, email, contactDelivery: "email", expectedPrice: 19990, paymentProvider: "transbank" };
  for (const channel of ["email", "tiktok"]) {
    const result = await purchase(request({ ...base, intent: "quote", contactDelivery: channel, tiktokHandle: "@test_shop.cl" }));
    assert.equal(result.status, 201);
    const payload = await result.json();
    const [saved] = await db.select().from(orders).where(eq(orders.orderNumber, payload.orderNumber));
    assert.equal(saved.paymentStatus, "not_started");
    assert.equal(saved.total, 0);
    assert.equal(saved.shipping, 0);
    assert.deepEqual(saved.items[0].contactSupplierIds, members.map((member) => member.id));
    assert.deepEqual(saved.items[0].includedContactNames, members.map((member) => member.name));
  }

  await db.update(suppliers).set({ contact: "" }).where(eq(suppliers.id, members[1].id));
  const missingMember = await purchase(request({ ...base, intent: "purchase" }));
  assert.equal(missingMember.status, 409);
  assert.equal((await getPublicSupplierOffers()).find((offer) => offer.id === bundle.id)?.canPurchase, false);
  await db.update(suppliers).set({ contact: members[1].contact }).where(eq(suppliers.id, members[1].id));
  const wrongPrice = await purchase(request({ ...base, intent: "purchase", expectedPrice: 1 }));
  assert.equal(wrongPrice.status, 409);
  console.log("PASS: both delivery channels preserve all three contacts; incomplete packs and altered prices are rejected.");

  const calls: { url: string; body: Record<string, unknown> }[] = [];
  globalThis.fetch = async (input, init) => {
    const url = typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
    const body = JSON.parse(String(init?.body ?? "{}")) as Record<string, unknown>;
    calls.push({ url, body });
    if (url.includes("webpay3gint.transbank.cl") && init?.method === "POST") {
      assert.equal(body.amount, 19990, "The gateway must receive the pack price, not the members' total.");
      return Response.json({ token: `TEST-ONLY-${marker}`, url: "https://webpay3gint.transbank.cl/webpayserver/initTransaction" });
    }
    if (url === "https://api.resend.com/emails") return Response.json({ id: `TEST-ONLY-${marker}` });
    throw new Error(`Unexpected network request in isolated test: ${url}`);
  };
  process.env.TRANSBANK_COMMERCE_CODE = `TEST-ONLY-${marker}`;
  process.env.TRANSBANK_API_KEY = randomBytes(32).toString("hex");
  process.env.TRANSBANK_ENV = "test";
  process.env.RESEND_API_KEY = `TEST-ONLY-${marker}`;
  process.env.RESEND_FROM_EMAIL = "Integration Test <test@example.invalid>";

  const started = await purchase(request({ ...base, intent: "purchase", price: 1, contactSupplierIds: [bundle.id], bundleSupplierIds: [bundle.id] }));
  assert.equal(started.status, 200);
  const startedPayload = await started.json();
  const [pending] = await db.select().from(orders).where(eq(orders.orderNumber, startedPayload.orderNumber));
  assert.equal(pending.paymentStatus, "pending");
  assert.equal(pending.total, 19990);
  assert.equal(pending.subtotal, 19990);
  assert.equal(pending.shipping, 0);
  assert.equal(pending.items.length, 1);
  assert.equal(pending.items[0].quantity, 1);
  assert.equal(pending.items[0].unitPrice, 19990);
  assert.deepEqual(pending.items[0].contactSupplierIds, members.map((member) => member.id));
  assert.equal((await sendConfirmationEmail(pending.orderNumber)).sent, false);
  assert.equal(calls.filter((call) => call.url.includes("resend")).length, 0);
  console.log("PASS: isolated checkout charges the server-side pack price once, without shipping or early disclosure.");

  // An explicitly isolated paid-state fixture exercises fulfillment; no real payment is committed.
  await db.update(orders).set({ paymentStatus: "paid" }).where(eq(orders.id, pending.id));
  await db.update(suppliers).set({ bundleSupplierIds: [] }).where(eq(suppliers.id, bundle.id));
  assert.equal((await sendConfirmationEmail(pending.orderNumber)).sent, true);
  const emailCalls = calls.filter((call) => call.url === "https://api.resend.com/emails");
  assert.equal(emailCalls.length, 1);
  const html = String(emailCalls[0].body.html);
  for (const member of members) assert(html.includes(member.contact));
  assert(!html.includes("NEVER-SEND-PACK-PLACEHOLDER"));
  assert.equal((await sendConfirmationEmail(pending.orderNumber)).sent, true);
  assert.equal(calls.filter((call) => call.url.includes("resend")).length, 1);
  const stockAfter = await db.select({ id: products.id, stock: products.stock }).from(products);
  assert.deepEqual(stockAfter.sort((a, b) => a.id - b.id), stockBefore.sort((a, b) => a.id - b.id));
  console.log("PASS: email contains the three purchased contacts, remains stable after pack edits, and is not duplicated.");
  console.log("All pack tests passed. All network responses were isolated test doubles; no real charge or email was made.");
}

async function cleanup() {
  globalThis.fetch = originalFetch;
  for (const [key, value] of previousEnv) {
    if (value === undefined) delete process.env[key]; else process.env[key] = value;
  }
  const testCustomers = await db.select({ id: customers.id }).from(customers).where(eq(customers.email, email));
  if (testCustomers.length) {
    const ids = testCustomers.map((customer) => customer.id);
    await db.delete(orders).where(inArray(orders.customerId, ids));
    await db.delete(customers).where(inArray(customers.id, ids));
  }
  if (fixtureIds.length) await db.delete(suppliers).where(inArray(suppliers.id, fixtureIds));
  await pool.end();
}

run().catch((error) => { console.error(error); process.exitCode = 1; }).finally(cleanup);
