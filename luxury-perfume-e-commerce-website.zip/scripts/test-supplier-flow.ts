import "dotenv/config";
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { eq, inArray } from "drizzle-orm";
import { NextRequest } from "next/server";
import { db, pool } from "@/db";
import { customers, orders, suppliers } from "@/db/schema";
import { getPublicProducts } from "@/lib/catalog";
import { getPublicSupplierOffers } from "@/lib/suppliers";
import { POST as purchase } from "@/app/api/suppliers/purchase/route";
import { GET as publicSuppliers } from "@/app/api/suppliers/route";
import { GET as adminSuppliers } from "@/app/api/admin/suppliers/route";
import { POST as deliver } from "@/app/api/admin/orders/[id]/deliver/route";
import { confirmOrderByNumber } from "@/lib/orders";
import { ADMIN_COOKIE, createAdminToken } from "@/lib/admin-auth";

const originalEnv = { session: process.env.ADMIN_SESSION_SECRET, code: process.env.TRANSBANK_COMMERCE_CODE, key: process.env.TRANSBANK_API_KEY };
const marker = `lpc-flow-${randomBytes(6).toString("hex")}`;
const email = `${marker}@example.invalid`;
let fixtureSupplierId: number | null = null;
const request = (body: unknown) => new NextRequest("https://store.example/api/suppliers/purchase", {
  method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
});

async function run() {
  const catalog = await getPublicProducts();
  const initialStock = new Map(catalog.map((product) => [product.id, product.stock]));
  const offers = await getPublicSupplierOffers();
  assert(offers.some((offer) => offer.category === "technology"));
  assert(offers.some((offer) => offer.category === "perfume"));
  assert(offers.some((offer) => offer.category === "wholesale"));
  console.log("PASS: three requested supplier categories are available.");

  const privateContent = `PRIVATE-CONTACT-${marker}`;
  const [fixture] = await db.insert(suppliers).values({ name: `TEST ONLY ${marker}`, category: "technology", description: "Temporary integration-test fixture; deleted after the test.", price: 14990, contact: privateContent, active: true }).returning();
  fixtureSupplierId = fixture.id;
  const publicPayload = await (await publicSuppliers()).json();
  assert(!JSON.stringify(publicPayload).includes(privateContent));
  assert(publicPayload.suppliers.every((offer: Record<string, unknown>) => !("contact" in offer)));
  console.log("PASS: private contacts never appear in the public API.");

  const base = { supplierId: fixture.id, intent: "quote", name: `TEST ONLY ${marker}`, email, contactDelivery: "email" };
  for (const channel of ["email", "tiktok"] as const) {
    const response = await purchase(request({ ...base, contactDelivery: channel, tiktokHandle: channel === "tiktok" ? "@test_shop.cl" : "" }));
    assert.equal(response.status, 201);
    const payload = await response.json();
    assert.equal(payload.requestCreated, true);
    assert(!JSON.stringify(payload).includes(privateContent));
    const [saved] = await db.select().from(orders).where(eq(orders.orderNumber, payload.orderNumber));
    assert.equal(saved.fulfillment, "digital");
    assert.equal(saved.shipping, 0);
    assert.equal(saved.total, 0);
    assert.equal(saved.paymentStatus, "not_started");
    assert.equal(saved.status, "awaiting_quote");
    assert.equal(saved.contactDelivery, channel);
    assert.equal(saved.items[0].supplierId, fixture.id);
    assert.equal(saved.items[0].productId, null);
    if (channel === "tiktok") assert.equal(saved.tiktokHandle, "@test_shop.cl");
    const rejectedConfirmation = await confirmOrderByNumber(saved.orderNumber, "TEST-ONLY-NO-CHARGE");
    assert.equal(rejectedConfirmation.confirmed, false, "A quote must never be treated as a confirmed purchase.");

    process.env.ADMIN_SESSION_SECRET = randomBytes(32).toString("hex");
    const deliveryRequest = new NextRequest(`https://store.example/api/admin/orders/${saved.id}/deliver`, { method: "POST", headers: { cookie: `${ADMIN_COOKIE}=${createAdminToken()}` } });
    const delivered = await deliver(deliveryRequest, { params: Promise.resolve({ id: String(saved.id) }) });
    assert.equal(delivered.status, 409, "Unpaid contacts must not be sent.");
  }
  console.log("PASS: email and TikTok requests persist without a charge, delivery, or stock change.");

  const invalidTikTok = await purchase(request({ ...base, contactDelivery: "tiktok", tiktokHandle: "" }));
  assert.equal(invalidTikTok.status, 400);
  const invalidEmail = await purchase(request({ ...base, email: "not-an-email" }));
  assert.equal(invalidEmail.status, 400);
  const wrongPrice = await purchase(request({ ...base, intent: "purchase", expectedPrice: 1, paymentProvider: "transbank" }));
  assert.equal(wrongPrice.status, 409);
  console.log("PASS: invalid recipients and client-side price tampering are rejected.");

  delete process.env.TRANSBANK_COMMERCE_CODE;
  delete process.env.TRANSBANK_API_KEY;
  const disabledPayment = await purchase(request({ ...base, intent: "purchase", expectedPrice: 14990, paymentProvider: "transbank" }));
  assert.equal(disabledPayment.status, 503);
  const unauthorized = await adminSuppliers(new NextRequest("https://store.example/api/admin/suppliers"));
  assert.equal(unauthorized.status, 401);
  const after = await getPublicProducts();
  assert(after.every((product) => initialStock.get(product.id) === product.stock));
  console.log("PASS: missing gateway credentials cannot initiate a charge; admin APIs are protected.");
  console.log("All supplier-flow tests passed. No real payment or email was initiated.");
}

async function cleanup() {
  const fixtures = await db.select({ id: customers.id }).from(customers).where(eq(customers.email, email));
  if (fixtures.length) {
    const ids = fixtures.map((customer) => customer.id);
    await db.delete(orders).where(inArray(orders.customerId, ids));
    await db.delete(customers).where(inArray(customers.id, ids));
  }
  if (fixtureSupplierId) await db.delete(suppliers).where(eq(suppliers.id, fixtureSupplierId));
  for (const [key, value] of [["ADMIN_SESSION_SECRET", originalEnv.session], ["TRANSBANK_COMMERCE_CODE", originalEnv.code], ["TRANSBANK_API_KEY", originalEnv.key]]) {
    if (value === undefined) delete process.env[key!]; else process.env[key!] = value;
  }
  await pool.end();
}

run().catch((error) => { console.error(error); process.exitCode = 1; }).finally(cleanup);
