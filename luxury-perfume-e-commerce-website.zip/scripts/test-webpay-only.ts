import "dotenv/config";
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { asc, eq, inArray } from "drizzle-orm";
import { NextRequest } from "next/server";
import { db, pool } from "@/db";
import { customers, orders, products, suppliers } from "@/db/schema";
import { getPublicProducts } from "@/lib/catalog";
import { getPublicSupplierOffers } from "@/lib/suppliers";
import { POST as perfumeCheckout } from "@/app/api/checkout/route";
import { POST as contactCheckout } from "@/app/api/suppliers/purchase/route";
import { supplierPaymentConfigurationError } from "@/lib/supplier-payment";

// These temporary test fixtures never create a real payment or contact a gateway.
const marker = `webpay-only-${randomBytes(6).toString("hex")}`;
const email = `${marker}@example.invalid`;
const originalFetch = globalThis.fetch;
const envKeys = ["TRANSBANK_COMMERCE_CODE", "TRANSBANK_API_KEY", "TRANSBANK_ENV", "MERCADOPAGO_ACCESS_TOKEN"];
const originalEnv = new Map(envKeys.map((key) => [key, process.env[key]]));
const fixtureIds: number[] = [];
const calls: { amount: number; return_url: string; buy_order: string }[] = [];
const request = (endpoint: string, body: unknown) => new NextRequest(`https://store.example${endpoint}`, {
  method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
});
const snapshot = async () => ({
  orders: await db.select().from(orders).orderBy(asc(orders.id)),
  customers: await db.select().from(customers).orderBy(asc(customers.id)),
});

async function run() {
  const catalog = await getPublicProducts();
  const publicOffers = await getPublicSupplierOffers();
  const product = catalog.find((item) => item.stock > 0)!;
  assert(product);
  const originalProducts = await db.select().from(products).orderBy(asc(products.id));
  const originalOffers = await db.select().from(suppliers).orderBy(asc(suppliers.id));
  const before = await snapshot();

  process.env.TRANSBANK_COMMERCE_CODE = `TEST-ONLY-${marker}`;
  process.env.TRANSBANK_API_KEY = randomBytes(32).toString("hex");
  process.env.TRANSBANK_ENV = "test";
  // Even configured legacy credentials must not enable another checkout gateway.
  process.env.MERCADOPAGO_ACCESS_TOKEN = `TEST-ONLY-DISABLED-${marker}`;
  globalThis.fetch = async (input, init) => {
    const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
    assert.equal(url, "https://webpay3gint.transbank.cl/rswebpaytransaction/api/webpay/v1.2/transactions");
    assert.equal(init?.method, "POST");
    const body = JSON.parse(String(init?.body)) as { amount: number; return_url: string; buy_order: string };
    assert(body.amount > 0 && Number.isSafeInteger(body.amount));
    assert(body.return_url.includes("/api/payments/transbank/return"));
    calls.push(body);
    return Response.json({ token: `${marker}-${calls.length}`, url: "https://webpay3gint.transbank.cl/webpayserver/initTransaction" });
  };

  const perfumeBody = { name: `TEST ONLY ${marker}`, email, phone: "+56911111111", fulfillment: "pickup", items: [{ productId: product.id, quantity: 1 }] };
  const contactBody = { name: `TEST ONLY ${marker}`, email, supplierId: publicOffers[0].id, expectedPrice: publicOffers[0].price, intent: "purchase", contactDelivery: "email" };
  for (const provider of ["mercadopago", "paypal", "", null]) {
    const fragrance = await perfumeCheckout(request("/api/checkout", { ...perfumeBody, paymentProvider: provider }));
    assert.equal(fragrance.status, 400);
    assert.match((await fragrance.json()).error, /Webpay Plus/);
    const contact = await contactCheckout(request("/api/suppliers/purchase", { ...contactBody, paymentProvider: provider }));
    assert.equal(contact.status, 400);
    assert.match((await contact.json()).error, /Webpay Plus/);
  }
  assert.equal(calls.length, 0);
  assert.deepEqual(await snapshot(), before);
  assert.match(supplierPaymentConfigurationError("mercadopago")!, /único medio de pago/);
  console.log("PASS: other payment methods are rejected before creating an order or making a network request.");

  delete process.env.TRANSBANK_API_KEY;
  const unavailable = await perfumeCheckout(request("/api/checkout", { ...perfumeBody, paymentProvider: "transbank" }));
  assert.equal(unavailable.status, 503);
  assert.equal(calls.length, 0);
  assert.deepEqual(await snapshot(), before);
  process.env.TRANSBANK_API_KEY = randomBytes(32).toString("hex");

  // Omitted provider defaults to Webpay; client-side prices cannot alter the total.
  const perfumeResponse = await perfumeCheckout(request("/api/checkout", { ...perfumeBody, total: 1 }));
  assert.equal(perfumeResponse.status, 200);
  const perfumeResult = await perfumeResponse.json();
  assert.equal(perfumeResult.provider, "transbank");
  assert(perfumeResult.token);
  assert.equal(calls[0].amount, product.price);
  const [perfumeOrder] = await db.select().from(orders).where(eq(orders.orderNumber, perfumeResult.orderNumber));
  assert.equal(perfumeOrder.paymentProvider, "transbank");
  assert.equal(perfumeOrder.paymentStatus, "pending");
  assert.equal(perfumeOrder.total, product.price);
  console.log("PASS: perfume checkout starts Webpay with the stored price and remains pending until official confirmation.");

  const categories = ["technology", "perfume", "wholesale"];
  const members = await db.insert(suppliers).values(categories.map((category, index) => ({
    name: `TEST ONLY ${marker} ${category}`, category, description: "Temporary isolated checkout fixture.",
    price: [11990, 10990, 12990][index], contact: `PRIVATE-${marker}-${category}`, active: true,
  }))).returning();
  fixtureIds.push(...members.map((member) => member.id));
  const [bundle] = await db.insert(suppliers).values({
    name: `TEST ONLY pack ${marker}`, category: "bundle", price: 19990, description: "Temporary isolated pack fixture.",
    bundleSupplierIds: members.map((member) => member.id), active: true,
  }).returning();
  fixtureIds.push(bundle.id);
  for (const [index, offer] of [members[0], bundle].entries()) {
    const response = await contactCheckout(request("/api/suppliers/purchase", {
      ...contactBody, supplierId: offer.id, expectedPrice: offer.price,
      ...(index === 0 ? { paymentProvider: "transbank" } : {}),
      contactDelivery: index === 0 ? "email" : "tiktok", tiktokHandle: "@test_shop.cl",
    }));
    assert.equal(response.status, 200);
    const result = await response.json();
    assert.equal(result.provider, "transbank");
    assert(result.token);
    const [saved] = await db.select().from(orders).where(eq(orders.orderNumber, result.orderNumber));
    assert.equal(saved.total, offer.price);
    assert.equal(saved.shipping, 0);
    assert.equal(saved.paymentProvider, "transbank");
    assert.equal(saved.paymentStatus, "pending");
    assert.equal(saved.confirmationEmailSentAt, null);
    assert.equal(saved.items[0].contactSupplierIds?.length, index === 0 ? 1 : 3);
  }
  assert.deepEqual(calls.map((call) => call.amount), [product.price, 11990, 19990]);
  assert(calls.slice(1).every((call) => call.return_url.includes("contact=1")));
  assert.deepEqual(await db.select().from(products).orderBy(asc(products.id)), originalProducts);
  const currentOffers = (await db.select().from(suppliers).orderBy(asc(suppliers.id))).filter((offer) => !fixtureIds.includes(offer.id));
  assert.deepEqual(currentOffers, originalOffers);
  console.log("PASS: single-contact and pack checkout use only Webpay, preserving prices, stock and delivery channels.");
  console.log("All Webpay-only checks passed. No real payment, stock deduction or email occurred.");
}

async function cleanup() {
  globalThis.fetch = originalFetch;
  for (const [key, value] of originalEnv) { if (value === undefined) delete process.env[key]; else process.env[key] = value; }
  const fixtureCustomers = await db.select({ id: customers.id }).from(customers).where(eq(customers.email, email));
  if (fixtureCustomers.length) {
    const ids = fixtureCustomers.map((customer) => customer.id);
    await db.delete(orders).where(inArray(orders.customerId, ids));
    await db.delete(customers).where(inArray(customers.id, ids));
  }
  if (fixtureIds.length) await db.delete(suppliers).where(inArray(suppliers.id, fixtureIds));
  await pool.end();
}

run().catch((error) => { console.error(error); process.exitCode = 1; }).finally(cleanup);
