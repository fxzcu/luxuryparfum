import { eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { requireAdmin } from "@/lib/require-admin";
import { sendConfirmationEmail } from "@/lib/orders";

export async function POST(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const denied = requireAdmin(request);
  if (denied) return denied;
  const id = Number((await context.params).id);
  if (!Number.isSafeInteger(id) || id < 1) return NextResponse.json({ error: "Pedido no válido." }, { status: 400 });
  const [order] = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  if (!order) return NextResponse.json({ error: "Pedido no encontrado." }, { status: 404 });
  if (order.fulfillment !== "digital" || order.contactDelivery !== "email") return NextResponse.json({ error: "La entrega por TikTok debe realizarse manualmente al usuario indicado." }, { status: 409 });
  if (order.paymentStatus !== "paid") return NextResponse.json({ error: "El contacto solo se envía después de confirmar el pago oficial." }, { status: 409 });
  const result = await sendConfirmationEmail(order.orderNumber);
  if (!result.sent) return NextResponse.json({ error: result.error }, { status: 503 });
  return NextResponse.json({ sent: true });
}
