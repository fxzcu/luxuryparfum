import { eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { requireAdmin } from "@/lib/require-admin";

const validShipmentStates = new Set(["preparing", "in_transit", "delivered"]);

export async function PATCH(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const denied = requireAdmin(request);
  if (denied) return denied;
  const id = Number((await context.params).id);
  if (!Number.isSafeInteger(id) || id < 1) return NextResponse.json({ error: "Pedido no válido." }, { status: 400 });
  let body: { shipmentStatus?: unknown };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Estado de despacho no válido." }, { status: 400 });
  }
  const shipmentStatus = body.shipmentStatus;
  if (typeof shipmentStatus !== "string" || !validShipmentStates.has(shipmentStatus)) {
    return NextResponse.json({ error: "Selecciona un estado de despacho válido." }, { status: 400 });
  }
  const [order] = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  if (!order) return NextResponse.json({ error: "No encontramos ese pedido." }, { status: 404 });
  if (order.paymentStatus !== "paid") {
    return NextResponse.json({ error: "El despacho solo se puede actualizar después de confirmar el pago." }, { status: 409 });
  }
  if (order.fulfillment === "digital" && shipmentStatus === "in_transit") return NextResponse.json({ error: "Los contactos digitales no requieren despacho físico." }, { status: 400 });
  const status = shipmentStatus === "in_transit" ? "shipped" : shipmentStatus;
  const [updated] = await db.update(orders).set({ shipmentStatus, status, updatedAt: new Date() }).where(eq(orders.id, id)).returning();
  return NextResponse.json({ order: updated });
}
