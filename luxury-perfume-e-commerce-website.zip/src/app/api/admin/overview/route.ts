import { count, desc, eq, inArray, lt, sum } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { customers, orders, products } from "@/db/schema";
import { requireAdmin } from "@/lib/require-admin";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const denied = requireAdmin(request);
  if (denied) return denied;

  const [productCount, orderCount, paidCount, revenue, lowStock, recentOrders] = await Promise.all([
    db.select({ value: count() }).from(products).where(eq(products.active, true)),
    db.select({ value: count() }).from(orders),
    db.select({ value: count() }).from(orders).where(inArray(orders.paymentStatus, ["paid", "paid_review"])),
    db.select({ value: sum(orders.total) }).from(orders).where(inArray(orders.paymentStatus, ["paid", "paid_review"])),
    db.select({ value: count() }).from(products).where(lt(products.stock, 4)),
    db
      .select({
        id: orders.id,
        orderNumber: orders.orderNumber,
        total: orders.total,
        paymentProvider: orders.paymentProvider,
        paymentStatus: orders.paymentStatus,
        status: orders.status,
        shipmentStatus: orders.shipmentStatus,
        fulfillment: orders.fulfillment,
        contactDelivery: orders.contactDelivery,
        tiktokHandle: orders.tiktokHandle,
        items: orders.items,
        confirmationEmailSentAt: orders.confirmationEmailSentAt,
        createdAt: orders.createdAt,
        customerName: customers.fullName,
        customerEmail: customers.email,
      })
      .from(orders)
      .leftJoin(customers, eq(orders.customerId, customers.id))
      .orderBy(desc(orders.createdAt))
      .limit(40),
  ]);

  return NextResponse.json({
    stats: {
      products: Number(productCount[0]?.value ?? 0),
      orders: Number(orderCount[0]?.value ?? 0),
      paidOrders: Number(paidCount[0]?.value ?? 0),
      revenue: Number(revenue[0]?.value ?? 0),
      lowStock: Number(lowStock[0]?.value ?? 0),
    },
    orders: recentOrders,
  });
}
