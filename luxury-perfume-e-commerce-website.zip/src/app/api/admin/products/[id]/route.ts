import { eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { normalizeProductInput } from "@/lib/product-input";
import { requireAdmin } from "@/lib/require-admin";

export async function PATCH(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const denied = requireAdmin(request);
  if (denied) return denied;
  const id = Number((await context.params).id);
  if (!Number.isSafeInteger(id) || id < 1) return NextResponse.json({ error: "Producto no válido." }, { status: 400 });
  const [existing] = await db.select().from(products).where(eq(products.id, id)).limit(1);
  if (!existing) return NextResponse.json({ error: "No encontramos ese perfume." }, { status: 404 });
  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Datos de producto inválidos." }, { status: 400 });
  }
  const values = normalizeProductInput(body, existing);
  if (!values) return NextResponse.json({ error: "Revisa los datos, precios, stock e imagen." }, { status: 400 });
  try {
    const [updated] = await db.update(products).set(values).where(eq(products.id, id)).returning();
    return NextResponse.json({ product: updated });
  } catch (error) {
    console.error("Unable to update product", error);
    return NextResponse.json({ error: "No se pudo guardar el cambio. Revisa si ya existe el mismo nombre y tamaño." }, { status: 409 });
  }
}

export async function DELETE(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const denied = requireAdmin(request);
  if (denied) return denied;
  const id = Number((await context.params).id);
  if (!Number.isSafeInteger(id) || id < 1) return NextResponse.json({ error: "Producto no válido." }, { status: 400 });
  const [deleted] = await db.delete(products).where(eq(products.id, id)).returning({ id: products.id });
  if (!deleted) return NextResponse.json({ error: "No encontramos ese perfume." }, { status: 404 });
  return NextResponse.json({ deleted: true });
}
