import { eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { suppliers } from "@/db/schema";
import { requireAdmin } from "@/lib/require-admin";
import { normalizeSupplierInput, validateSupplierBundle } from "@/lib/supplier-input";

export async function PATCH(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const denied = requireAdmin(request);
  if (denied) return denied;
  const id = Number((await context.params).id);
  if (!Number.isSafeInteger(id) || id < 1) return NextResponse.json({ error: "Proveedor no válido." }, { status: 400 });
  const [existing] = await db.select().from(suppliers).where(eq(suppliers.id, id)).limit(1);
  if (!existing) return NextResponse.json({ error: "No encontramos ese proveedor." }, { status: 404 });
  let body: Record<string, unknown>;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Datos de proveedor inválidos." }, { status: 400 }); }
  const values = normalizeSupplierInput(body, existing);
  if (!values) return NextResponse.json({ error: "Revisa nombre, categoría, descripción, imagen y precio en CLP." }, { status: 400 });
  if (!await validateSupplierBundle(values.category, values.bundleSupplierIds)) return NextResponse.json({ error: "El pack debe incluir un proveedor de tecnología, uno de perfumes y uno de perfumes al por mayor, sin repetir contactos." }, { status: 400 });
  const [supplier] = await db.update(suppliers).set(values).where(eq(suppliers.id, id)).returning();
  return NextResponse.json({ supplier });
}
export async function DELETE(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const denied = requireAdmin(request);
  if (denied) return denied;
  const id = Number((await context.params).id);
  if (!Number.isSafeInteger(id) || id < 1) return NextResponse.json({ error: "Proveedor no válido." }, { status: 400 });
  // Archive instead of deleting paid delivery content referenced by an existing order.
  const [archived] = await db.update(suppliers).set({ active: false, updatedAt: new Date() }).where(eq(suppliers.id, id)).returning({ id: suppliers.id });
  if (!archived) return NextResponse.json({ error: "No encontramos ese proveedor." }, { status: 404 });
  return NextResponse.json({ deleted: true });
}
