import { asc } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { suppliers } from "@/db/schema";
import { requireAdmin } from "@/lib/require-admin";
import { normalizeSupplierInput, validateSupplierBundle } from "@/lib/supplier-input";
import { ensureSupplierOffers } from "@/lib/suppliers";

export const dynamic = "force-dynamic";
export async function GET(request: NextRequest) {
  const denied = requireAdmin(request);
  if (denied) return denied;
  await ensureSupplierOffers();
  return NextResponse.json({ suppliers: await db.select().from(suppliers).orderBy(asc(suppliers.id)) }, { headers: { "Cache-Control": "private, no-store" } });
}
export async function POST(request: NextRequest) {
  const denied = requireAdmin(request);
  if (denied) return denied;
  let body: Record<string, unknown>;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Datos de proveedor inválidos." }, { status: 400 }); }
  const values = normalizeSupplierInput(body);
  if (!values) return NextResponse.json({ error: "Revisa nombre, descripción, categoría y precio. El precio debe ser un entero positivo o quedar vacío para solicitar cotización." }, { status: 400 });
  if (!await validateSupplierBundle(values.category, values.bundleSupplierIds)) return NextResponse.json({ error: "El pack debe incluir un proveedor de tecnología, uno de perfumes y uno de perfumes al por mayor, sin repetir contactos." }, { status: 400 });
  const [supplier] = await db.insert(suppliers).values(values).returning();
  return NextResponse.json({ supplier }, { status: 201 });
}
