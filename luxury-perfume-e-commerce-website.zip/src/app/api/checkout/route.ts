import { randomBytes } from "node:crypto";
import { and, eq, inArray } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { customers, orders, products, type OrderLine } from "@/db/schema";
import { SHIPPING_FEE, SHIPPING_THRESHOLD } from "@/lib/catalog";

export const runtime = "nodejs";

function isValidEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function orderCode() {
  return `LP${Date.now().toString(36).slice(-8).toUpperCase()}${randomBytes(3).toString("hex").toUpperCase()}`;
}

function transbankConfiguration() {
  const commerceCode = process.env.TRANSBANK_COMMERCE_CODE;
  const apiKey = process.env.TRANSBANK_API_KEY;
  const production = process.env.TRANSBANK_ENV === "production";
  return {
    commerceCode,
    apiKey,
    endpoint: production
      ? "https://webpay3g.transbank.cl/rswebpaytransaction/api/webpay/v1.2/transactions"
      : "https://webpay3gint.transbank.cl/rswebpaytransaction/api/webpay/v1.2/transactions",
  };
}

export async function POST(request: NextRequest) {
  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Revisa los datos del checkout e inténtalo otra vez." }, { status: 400 });
  }

  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return NextResponse.json({ error: "Solicitud de pago inválida." }, { status: 400 });
  }
  if (body.paymentProvider !== undefined && body.paymentProvider !== "transbank") {
    return NextResponse.json({ error: "Webpay Plus es el único medio de pago disponible." }, { status: 400 });
  }
  const paymentProvider = "transbank";
  const tbk = transbankConfiguration();
  if (!tbk.commerceCode || !tbk.apiKey) {
    return NextResponse.json({ error: "Webpay aún no está activado. Configura sus credenciales oficiales de integración para continuar; no se creó ningún pedido ni se realizó un cobro." }, { status: 503 });
  }

  const name = typeof body.name === "string" ? body.name.trim().slice(0, 120) : "";
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase().slice(0, 180) : "";
  const phone = typeof body.phone === "string" ? body.phone.trim().slice(0, 40) : "";
  const fulfillment = body.fulfillment === "pickup" ? "pickup" : "delivery";
  const address = typeof body.address === "string" ? body.address.trim().slice(0, 240) : "";
  const comuna = typeof body.comuna === "string" ? body.comuna.trim().slice(0, 100) : "";
  const region = typeof body.region === "string" ? body.region.trim().slice(0, 100) : "";
  const customerNote = typeof body.customerNote === "string" ? body.customerNote.trim().slice(0, 500) : "";

  if (name.length < 2 || !isValidEmail(email) || phone.length < 6) {
    return NextResponse.json({ error: "Completa nombre, correo y teléfono válidos." }, { status: 400 });
  }
  if (fulfillment === "delivery" && (!address || !comuna || !region)) {
    return NextResponse.json({ error: "Para el despacho a domicilio necesitamos dirección, comuna y región." }, { status: 400 });
  }
  if (!Array.isArray(body.items) || body.items.length < 1 || body.items.length > 30) {
    return NextResponse.json({ error: "El carrito está vacío o contiene demasiados productos." }, { status: 400 });
  }

  const requested = new Map<number, number>();
  for (const rawItem of body.items) {
    if (!rawItem || typeof rawItem !== "object") continue;
    const item = rawItem as { productId?: unknown; quantity?: unknown };
    const productId = Number(item.productId);
    const quantity = Number(item.quantity);
    if (!Number.isSafeInteger(productId) || productId < 1 || !Number.isSafeInteger(quantity) || quantity < 1 || quantity > 10) {
      return NextResponse.json({ error: "Hay una cantidad o producto no válido en el carrito." }, { status: 400 });
    }
    requested.set(productId, (requested.get(productId) ?? 0) + quantity);
  }
  if (requested.size === 0 || [...requested.values()].some((quantity) => quantity > 10)) {
    return NextResponse.json({ error: "La cantidad máxima por perfume es 10 unidades." }, { status: 400 });
  }

  const selectedProducts = await db
    .select()
    .from(products)
    .where(and(inArray(products.id, [...requested.keys()]), eq(products.active, true)));
  if (selectedProducts.length !== requested.size) {
    return NextResponse.json({ error: "Uno de los perfumes ya no está disponible." }, { status: 409 });
  }
  for (const product of selectedProducts) {
    if (product.stock < (requested.get(product.id) ?? 0)) {
      return NextResponse.json({ error: `No quedan suficientes unidades de ${product.name}.` }, { status: 409 });
    }
  }

  const orderItems: OrderLine[] = selectedProducts.map((product) => ({
    productId: product.id,
    slug: product.slug,
    brand: product.brand,
    name: product.name,
    size: product.size,
    image: product.image,
    quantity: requested.get(product.id) ?? 1,
    unitPrice: product.price,
  }));
  const subtotal = orderItems.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  const shipping = fulfillment === "pickup" || subtotal >= SHIPPING_THRESHOLD ? 0 : SHIPPING_FEE;
  const total = subtotal + shipping;
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "") || request.nextUrl.origin;
  const number = orderCode();

  const [customer] = await db
    .insert(customers)
    .values({ fullName: name, email, phone })
    .returning({ id: customers.id });
  if (!customer) return NextResponse.json({ error: "No pudimos guardar tus datos. Inténtalo otra vez." }, { status: 500 });

  const [order] = await db
    .insert(orders)
    .values({
      orderNumber: number,
      customerId: customer.id,
      items: orderItems,
      subtotal,
      shipping,
      total,
      fulfillment,
      address,
      comuna,
      region,
      customerNote,
      paymentProvider,
    })
    .returning({ id: orders.id, orderNumber: orders.orderNumber });
  if (!order) return NextResponse.json({ error: "No pudimos crear el pedido." }, { status: 500 });

  try {
    const response = await fetch(tbk.endpoint, {
      method: "POST",
      headers: {
        "Tbk-Api-Key-Id": tbk.commerceCode,
        "Tbk-Api-Key-Secret": tbk.apiKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        buy_order: order.orderNumber,
        session_id: `LPC-${order.id}`,
        amount: total,
        return_url: `${baseUrl}/api/payments/transbank/return`,
      }),
      signal: AbortSignal.timeout(15_000),
    });
    const result = (await response.json().catch(() => ({}))) as { token?: string; url?: string; error_message?: string };
    if (!response.ok || !result.token || !result.url) {
      throw new Error(result.error_message || "Transbank no pudo iniciar la transacción.");
    }
    await db.update(orders).set({ paymentReference: result.token, updatedAt: new Date() }).where(eq(orders.id, order.id));
    return NextResponse.json({ provider: "transbank", orderNumber: order.orderNumber, url: result.url, token: result.token });
  } catch (error) {
    console.error("Payment provider initialization failed", error);
    await db
      .update(orders)
      .set({ paymentStatus: "error", status: "payment_failed", updatedAt: new Date() })
      .where(eq(orders.id, order.id));
    return NextResponse.json({ error: "No se pudo iniciar el pago con la pasarela. Tu tarjeta no fue cobrada; inténtalo nuevamente o contáctanos." }, { status: 502 });
  }
}
