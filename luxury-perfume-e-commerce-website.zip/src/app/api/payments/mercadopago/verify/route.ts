import { NextRequest, NextResponse } from "next/server";
import { confirmMercadoPagoPayment, fetchMercadoPagoPayment } from "@/lib/mercadopago";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const paymentId = request.nextUrl.searchParams.get("payment_id") || request.nextUrl.searchParams.get("collection_id");
  if (!paymentId || !/^\d{1,24}$/.test(paymentId)) {
    return NextResponse.json({ error: "Todavía no hay una confirmación de pago disponible." }, { status: 400 });
  }
  try {
    const payment = await fetchMercadoPagoPayment(paymentId);
    if (!payment) return NextResponse.json({ error: "No se pudo consultar la confirmación en Mercado Pago." }, { status: 503 });
    const confirmation = await confirmMercadoPagoPayment(payment);
    return NextResponse.json({
      status: payment.status ?? "pending",
      confirmed: confirmation.confirmed,
      stockConflict: confirmation.stockConflict,
      orderNumber: payment.external_reference ?? null,
    });
  } catch (error) {
    console.error("Mercado Pago return verification failed", error);
    return NextResponse.json({ error: "No se pudo comprobar el pago. El estado se actualizará al recibir la confirmación oficial." }, { status: 503 });
  }
}
