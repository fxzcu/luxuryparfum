import { NextRequest, NextResponse } from "next/server";
import { getPublicProducts } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const products = await getPublicProducts();
  const params = request.nextUrl.searchParams;
  const search = (params.get("q") || "").trim().toLocaleLowerCase("es-CL");
  const brand = params.get("brand");
  const gender = params.get("gender");
  const family = params.get("family");
  const size = params.get("size");
  const minPrice = Number(params.get("min") || 0);
  const maxPrice = Number(params.get("max") || Number.MAX_SAFE_INTEGER);
  const sort = params.get("sort");

  const filtered = products.filter((product) => {
    const searchable = `${product.brand} ${product.name}`.toLocaleLowerCase("es-CL");
    return (!search || searchable.includes(search))
      && (!brand || product.brand === brand)
      && (!gender || product.gender === gender)
      && (!family || product.family === family)
      && (!size || product.size === size)
      && product.price >= minPrice
      && product.price <= maxPrice;
  });
  if (sort === "price_asc") filtered.sort((a, b) => a.price - b.price);
  else if (sort === "price_desc") filtered.sort((a, b) => b.price - a.price);
  else if (sort === "name") filtered.sort((a, b) => a.name.localeCompare(b.name, "es"));

  return NextResponse.json({ products: filtered, total: filtered.length });
}
