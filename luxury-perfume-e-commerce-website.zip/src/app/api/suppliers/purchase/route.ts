import { randomBytes } from "node:crypto";
import { eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { customers, orders, type OrderLine } from "@/db/schema";
import { getSupplierOfferRecords } from "@/lib/suppliers";
import { resolveOfferContacts } from "@/lib/supplier-bundles";
import { initiateSupplierPayment, supplierPaymentConfigurationError } from "@/lib/supplier-payment";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const origin = request.headers.get("origin");
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "") || request.nextUrl.origin;
  if (origin && origin !== request.nextUrl.origin && origin !== siteUrl) return NextResponse.json({ error: "Origen de solicitud inválido." }, { status: 403 });
  let body: Record<string, unknown>;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Revisa los datos de tu solicitud." }, { status: 400 }); }
  if (!body || typeof body !== "object" || Array.isArray(body)) return NextResponse.json({ error: "Solicitud inválida." }, { status: 400 });
  if (body.paymentProvider !== undefined && body.paymentProvider !== "transbank") return NextResponse.json({ error: "Webpay Plus es el único medio de pago disponible." }, { status: 400 });
  const id = Number(body.supplierId);
  const name = typeof body.name === "string" ? body.name.trim().slice(0, 120) : "";
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase().slice(0, 180) : "";
  const phone = typeof body.phone === "string" ? body.phone.trim().slice(0, 40) : "";
  const contactDelivery = body.contactDelivery;
  const tiktokHandle = typeof body.tiktokHandle === "string" ? body.tiktokHandle.trim().replace(/^@/, "") : "";
  const quote = body.intent === "quote";
  if (!Number.isSafeInteger(id) || id < 1 || name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return NextResponse.json({ error: "Completa nombre y correo válidos." }, { status: 400 });
  if (contactDelivery !== "email" && contactDelivery !== "tiktok") return NextResponse.json({ error: "Elige correo electrónico o TikTok para recibir tus contactos." }, { status: 400 });
  if (contactDelivery === "tiktok" && !/^[a-zA-Z0-9_.]{2,24}$/.test(tiktokHandle)) return NextResponse.json({ error: "Ingresa un usuario de TikTok válido, por ejemplo @tuusuario." }, { status: 400 });
  if (!quote && body.intent !== "purchase") return NextResponse.json({ error: "Selecciona una acción válida." }, { status: 400 });

  const records = await getSupplierOfferRecords();
  const supplier = records.find((offer) => offer.id === id && offer.active);
  if (!supplier) return NextResponse.json({ error: "Esta oferta ya no está disponible." }, { status: 404 });
  const included = resolveOfferContacts(supplier, records);
  const isBundle = supplier.category === "bundle";
  if (!quote && (!supplier.price || supplier.price < 1 || !included.ready)) return NextResponse.json({ error: isBundle ? "El pack está pendiente de disponibilidad de sus tres contactos. Puedes solicitarlo sin realizar un pago." : "El contacto está pendiente de disponibilidad o precio. Puedes solicitar información sin realizar un pago." }, { status: 409 });
  if (!quote && Number(body.expectedPrice) !== supplier.price) return NextResponse.json({ error: "El precio ha cambiado. Actualiza la página para revisarlo antes de pagar." }, { status: 409 });
  const provider = quote ? "quotation" : "transbank";
  if (!quote) {
    const error = supplierPaymentConfigurationError(provider);
    if (error) return NextResponse.json({ error }, { status: 503 });
  }
  // Use the stored offer price, not the sum of members or any client-supplied amount.
  const total = quote ? 0 : supplier.price!;
  const number = `LC${Date.now().toString(36).toUpperCase()}${randomBytes(4).toString("hex").toUpperCase()}`;
  const items: OrderLine[] = [{
    productId: null, supplierId: supplier.id, kind: "supplier_contact",
    contactSupplierIds: included.contacts.map((contact) => contact.id),
    includedContactNames: included.contacts.map((contact) => contact.name),
    slug: `contacto-${supplier.id}`, brand: "Luxury Parfum CL", name: supplier.name,
    size: isBundle ? "Pack de 3 contactos digitales" : "Contacto digital", image: supplier.logo,
    quantity: 1, unitPrice: total,
  }];
  const listedPrice = supplier.price ? new Intl.NumberFormat("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 }).format(supplier.price) : "por confirmar";
  const order = await db.transaction(async (tx) => {
    const [customer] = await tx.insert(customers).values({ fullName: name, email, phone }).returning();
    const [created] = await tx.insert(orders).values({
      orderNumber: number, customerId: customer.id, items, subtotal: total, shipping: 0, total,
      fulfillment: "digital", contactDelivery, tiktokHandle: contactDelivery === "tiktok" ? `@${tiktokHandle}` : "",
      paymentProvider: provider, paymentStatus: quote ? "not_started" : "pending", status: quote ? "awaiting_quote" : "pending_payment",
      customerNote: quote
        ? `Solicitud sin cobro. Precio publicado: ${listedPrice}. Confirmar disponibilidad antes del pago. Incluye: ${included.contacts.map((contact) => contact.name).join(", ")}.`
        : `Entrega de ${isBundle ? "los 3 contactos del pack" : "un contacto digital"}. No incluye productos físicos.`,
    }).returning();
    return created;
  });
  if (quote) return NextResponse.json({ requestCreated: true, orderNumber: order.orderNumber, message: `Solicitud recibida${supplier.price ? ` al precio publicado de ${listedPrice}` : ""}. Te confirmaremos la disponibilidad por el canal elegido antes de pagar. No se realizó ningún cobro.` }, { status: 201 });
  try {
    const payment = await initiateSupplierPayment(order, siteUrl);
    await db.update(orders).set({ paymentReference: payment.reference, updatedAt: new Date() }).where(eq(orders.id, order.id));
    return NextResponse.json({ provider: payment.provider, url: payment.url, token: payment.token, orderNumber: order.orderNumber });
  } catch (error) {
    console.error("Unable to start supplier payment", error);
    await db.update(orders).set({ paymentStatus: "error", status: "payment_failed", updatedAt: new Date() }).where(eq(orders.id, order.id));
    return NextResponse.json({ error: "No se pudo iniciar el pago oficial. No se confirmó ningún cobro. Inténtalo nuevamente." }, { status: 502 });
  }
}
