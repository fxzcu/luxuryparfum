import { NextResponse } from "next/server";
import { getPublicSupplierOffers } from "@/lib/suppliers";

export const dynamic = "force-dynamic";
export async function GET() {
  // The private contact is deliberately absent from the public response.
  return NextResponse.json({ suppliers: await getPublicSupplierOffers() });
}
