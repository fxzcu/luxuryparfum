import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import "./admin.css";
import "./detail.css";
import "./supplier-shop.css";
import "./supplier-bundle.css";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "https://luxuryparfum.cl"),
  title: {
    default: "Luxury Parfum CL | Tu esencia, tu identidad",
    template: "%s · Luxury Parfum CL",
  },
  description: "Descubre perfumes originales de diseñador y de autor. Burberry, Dior, Creed, Versace, Valentino y más, con despacho en Chile.",
  applicationName: "Luxury Parfum CL",
  keywords: ["perfumes originales", "perfumes Chile", "fragancias", "perfumería de lujo", "Luxury Parfum CL"],
  openGraph: {
    type: "website",
    locale: "es_CL",
    siteName: "Luxury Parfum CL",
    title: "Luxury Parfum CL | Tu esencia, tu identidad",
    description: "Fragancias extraordinarias para los momentos que merecen quedarse contigo.",
  },
  twitter: {
    card: "summary_large_image",
    title: "Luxury Parfum CL | Tu esencia, tu identidad",
    description: "Perfumería selecta con despacho en Chile.",
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="es-CL">
      <body>{children}</body>
    </html>
  );
}
