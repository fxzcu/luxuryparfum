import type { Metadata } from "next";
import { notFound } from "next/navigation";
import ProductDetail from "@/components/product-detail";
import { getPublicProductBySlug } from "@/lib/catalog";

export const dynamic = "force-dynamic";

type PageProps = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const product = await getPublicProductBySlug(slug);
  if (!product) return { title: "Perfume no encontrado" };
  return {
    title: `${product.brand} ${product.name} ${product.size}`,
    description: `${product.name} de ${product.brand}, ${product.size}. Perfumería selecta con despacho en Chile en Luxury Parfum CL.`,
    openGraph: {
      title: `${product.brand} ${product.name} | Luxury Parfum CL`,
      description: `${product.name} · ${product.family} · ${product.size}`,
      images: product.image ? [{ url: product.image }] : [],
    },
  };
}

export default async function PerfumePage({ params }: PageProps) {
  const { slug } = await params;
  const product = await getPublicProductBySlug(slug);
  if (!product) notFound();
  return <ProductDetail product={product} />;
}
