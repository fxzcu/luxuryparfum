import type { MetadataRoute } from "next";
import { getPublicProducts } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const siteUrl = (process.env.NEXT_PUBLIC_SITE_URL || "https://luxuryparfum.cl").replace(/\/$/, "");
  const catalog = await getPublicProducts();
  return [
    { url: siteUrl, lastModified: new Date(), changeFrequency: "daily", priority: 1 },
    ...catalog.map((product) => ({
      url: `${siteUrl}/perfumes/${product.slug}`,
      lastModified: new Date(),
      changeFrequency: "weekly" as const,
      priority: product.featured ? 0.85 : 0.65,
    })),
  ];
}
