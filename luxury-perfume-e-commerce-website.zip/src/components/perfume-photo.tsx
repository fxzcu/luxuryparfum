"use client";

import { useState } from "react";

type PhotoProduct = { image: string; brand: string; name: string };
const genericImages = new Set(["/images/perfume-rose.jpg", "/images/perfume-wood.jpg", "/images/perfume-amber.jpg"]);

export default function PerfumePhoto({ product, className = "", eager = false }: { product: PhotoProduct; className?: string; eager?: boolean }) {
  const [failedUrl, setFailedUrl] = useState<string | null>(null);
  const valid = product.image && !genericImages.has(product.image) && failedUrl !== product.image;
  if (!valid) return <div className={`${className} perfume-photo-pending`} role="img" aria-label={`Fotografía de ${product.brand} ${product.name} pendiente de verificación`}><span className="pending-photo-brand">{product.brand}</span><span className="pending-photo-monogram" aria-hidden="true">LP</span><span className="pending-photo-title">{product.name}</span><small>Fotografía de esta edición<br />en actualización</small></div>;
  return <img className={`${className} original-perfume-photo`} src={product.image} alt={`${product.brand} ${product.name} · fotografía del producto`} loading={eager ? "eager" : "lazy"} decoding="async" onError={() => setFailedUrl(product.image)} />;
}
