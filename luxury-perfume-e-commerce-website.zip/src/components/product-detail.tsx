"use client";

import Link from "next/link";
import PerfumePhoto from "@/components/perfume-photo";
import { useState } from "react";
import type { StoreProduct } from "@/components/storefront";

const currency = (amount: number) => new Intl.NumberFormat("es-CL", {
  style: "currency",
  currency: "CLP",
  maximumFractionDigits: 0,
}).format(amount);

export default function ProductDetail({ product }: { product: StoreProduct }) {
  const [message, setMessage] = useState("");
  const discount = Math.round((1 - product.price / Math.max(product.retailPrice, 1)) * 100);

  function addToBag(andCheckout = false) {
    try {
      const saved = window.localStorage.getItem("lpc-cart-v1");
      const cart = saved ? JSON.parse(saved) as (StoreProduct & { quantity: number })[] : [];
      const existing = cart.find((line) => line.id === product.id);
      if (existing) existing.quantity = Math.min(existing.quantity + 1, product.stock, 10);
      else cart.push({ ...product, quantity: 1 });
      window.localStorage.setItem("lpc-cart-v1", JSON.stringify(cart));
      if (andCheckout) window.location.assign("/?cart=open");
      else setMessage("Fragancia añadida a tu bolsa. Tu selección queda guardada en este navegador.");
    } catch {
      setMessage("No pudimos guardar el carrito en este navegador. Inténtalo desde el catálogo.");
    }
  }

  return (
    <main className="product-detail-page">
      <div className="detail-topbar"><Link href="/" className="brand-lockup"><span className="brand-monogram">LP</span><span className="brand-wordmark"><strong>LUXURY PARFUM</strong><small>CHILE · FRAGANCIAS SELECTAS</small></span></Link><Link href="/#catalogo" className="detail-return">← Volver a la colección</Link></div>
      <div className="detail-breadcrumb"><Link href="/">Inicio</Link><span>/</span><Link href="/#catalogo">Perfumes</Link><span>/</span><span>{product.brand}</span></div>
      <div className="detail-layout page-shell">
        <div className="detail-image-frame"><span className="discount-tag">−{discount}%</span><PerfumePhoto product={product} eager /></div>
        <section className="detail-copy"><p className="eyebrow"><span className="eyebrow-rule" /> {product.brand.toUpperCase()}</p><h1>{product.name}</h1><p className="detail-edition">{product.size === "S/D" ? "Tamaño por confirmar" : product.size} <span>·</span> {product.gender} <span>·</span> {product.family}</p><div className="detail-prices"><strong>{currency(product.price)}</strong><del>{currency(product.retailPrice)}</del><span>Precio especial</span></div><p className="detail-description">{product.description}</p><div className="detail-availability"><span className={product.stock > 0 ? "availability-dot" : "availability-dot is-empty"} />{product.stock > 0 ? product.stock <= 2 ? "Últimas unidades disponibles" : "Disponible para compra" : "Agotado temporalmente"}</div><div className="detail-fact"><span>FAMILIA OLFATIVA</span><strong>{product.family}</strong><p>{product.notes.join(" · ")}</p><small>La familia y notas pueden variar según la edición exacta. Escríbenos si necesitas asesoría de notas específicas.</small></div><div className="detail-fact"><span>DURACIÓN ESTIMADA</span><strong>Depende de cada piel</strong><p>La duración y proyección varían según la concentración, el clima y el tipo de piel. Consulta con nuestro equipo por esta referencia.</p></div><p className="shipping-time-note">El envío demora entre <strong>14 y 18 días</strong> desde la confirmación del pago.</p><div className="detail-buy-buttons"><button className="button button-dark" type="button" disabled={product.stock < 1} onClick={() => addToBag()}>Añadir a la bolsa <span>＋</span></button><button className="button button-outline" type="button" disabled={product.stock < 1} onClick={() => addToBag(true)}>Comprar ahora <span>→</span></button></div>{message && <p className="detail-message" role="status">✦ {message}</p>}<div className="detail-assurance"><span>◇</span> Envío entre 14 y 18 días · Gratis desde $120.000</div></section>
      </div>
      <section className="detail-extra page-shell"><p className="eyebrow">LA EXPERIENCIA LUXURY PARFUM</p><h2>Elegida para ser <em>recordada.</em></h2><p>Un perfume es una firma personal. Si buscas ayuda para elegir una fragancia, nuestro equipo puede orientarte antes de tu compra.</p><Link href="https://wa.me/?text=Hola%2C%20quisiera%20asesor%C3%ADa%20sobre%20el%20perfume" className="text-link" target="_blank">Pedir asesoría <span>→</span></Link></section>
      <footer className="detail-footer"><Link href="/">LUXURY PARFUM CL</Link><span>FRAGANCIAS SELECTAS · CHILE</span><Link href="/#preguntas">Preguntas frecuentes</Link></footer>
    </main>
  );
}
