"use client";

import Link from "next/link";
import SupplierShop, { type SupplierOffer } from "@/components/supplier-shop";
import PerfumePhoto from "@/components/perfume-photo";
import WebpayPaymentMethod from "@/components/webpay-payment-method";
import { useEffect, useMemo, useState, type FormEvent } from "react";

export type StoreProduct = {
  id: number;
  slug: string;
  brand: string;
  name: string;
  size: string;
  price: number;
  retailPrice: number;
  stock: number;
  availability: string;
  gender: string;
  family: string;
  image: string;
  description: string;
  notes: string[];
  featured: boolean;
};

type CartLine = StoreProduct & { quantity: number };

const currency = (amount: number) => new Intl.NumberFormat("es-CL", {
  style: "currency",
  currency: "CLP",
  maximumFractionDigits: 0,
}).format(amount);

function Icon({ name, size = 19 }: { name: "bag" | "search" | "menu" | "close" | "arrow" | "plus" | "minus" | "check"; size?: number }) {
  const common = { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.6, strokeLinecap: "round" as const, strokeLinejoin: "round" as const, "aria-hidden": true as const };
  if (name === "bag") return <svg {...common}><path d="M5.5 8.5h13l1 12h-15z"/><path d="M9 9V6a3 3 0 0 1 6 0v3"/></svg>;
  if (name === "search") return <svg {...common}><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 4.2 4.2"/></svg>;
  if (name === "menu") return <svg {...common}><path d="M4 7h16M4 12h16M4 17h16"/></svg>;
  if (name === "close") return <svg {...common}><path d="m6 6 12 12M18 6 6 18"/></svg>;
  if (name === "arrow") return <svg {...common}><path d="M4 12h15M13 5l7 7-7 7"/></svg>;
  if (name === "plus") return <svg {...common}><path d="M12 5v14M5 12h14"/></svg>;
  if (name === "minus") return <svg {...common}><path d="M5 12h14"/></svg>;
  return <svg {...common}><path d="m5 12 4 4L19 6"/></svg>;
}

function ProductCard({ product, onAdd, onBuyNow, onQuickView }: { product: StoreProduct; onAdd: (product: StoreProduct) => void; onBuyNow: (product: StoreProduct) => void; onQuickView: (product: StoreProduct) => void }) {
  const discount = Math.round((1 - product.price / Math.max(product.retailPrice, 1)) * 100);
  return (
    <article className="product-card">
      <div className="product-image-wrap" role="button" tabIndex={0} onClick={() => onQuickView(product)} onKeyDown={(event) => event.key === "Enter" && onQuickView(product)} aria-label={`Ver ${product.name}`}>
        <PerfumePhoto className="product-image" product={product} />
        <span className="discount-tag">−{discount}%</span>
        {product.stock <= 2 && <span className="stock-tag">Últimas unidades</span>}
        <button type="button" className="quick-view" onClick={(event) => { event.stopPropagation(); onQuickView(product); }}>Vista rápida</button>
      </div>
      <div className="product-card-copy">
        <p className="product-brand">{product.brand}</p>
        <Link href={`/perfumes/${product.slug}`} className="product-title">{product.name}</Link>
        <p className="product-size">{product.size === "S/D" ? "Tamaño por confirmar" : product.size} <span>·</span> {product.gender}</p>
        <div className="product-price-row">
          <strong>{currency(product.price)}</strong>
          <del>{currency(product.retailPrice)}</del>
        </div>
        <div className="product-card-actions">
          <button className="button button-dark add-to-cart" type="button" onClick={() => onAdd(product)} disabled={product.stock < 1}>
            {product.stock < 1 ? "Agotado" : "Añadir"}<Icon name="plus" size={16} />
          </button>
          <button className="buy-now-link" type="button" disabled={product.stock < 1} onClick={() => onBuyNow(product)}>Comprar ahora</button>
        </div>
      </div>
    </article>
  );
}

export default function Storefront({ products, suppliers }: { products: StoreProduct[]; suppliers: SupplierOffer[] }) {
  const [cart, setCart] = useState<CartLine[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [quickProduct, setQuickProduct] = useState<StoreProduct | null>(null);
  const [search, setSearch] = useState("");
  const [gender, setGender] = useState("Todos");
  const [brand, setBrand] = useState("Todas las marcas");
  const [family, setFamily] = useState("Todas las familias");
  const [sizeFilter, setSizeFilter] = useState("Todos los tamaños");
  const [maxPrice, setMaxPrice] = useState(650000);
  const [sort, setSort] = useState("featured");
  const [visibleCount, setVisibleCount] = useState(12);
  const [toast, setToast] = useState("");
  const [paymentNotice, setPaymentNotice] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [checkoutError, setCheckoutError] = useState("");
  const [form, setForm] = useState({ name: "", email: "", phone: "", fulfillment: "delivery", address: "", comuna: "", region: "", customerNote: "" });

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem("lpc-cart-v1");
      if (saved) {
        const parsed = JSON.parse(saved) as CartLine[];
        if (Array.isArray(parsed)) {
          const currentById = new Map(products.map((product) => [product.id, product]));
          const synchronized = parsed.flatMap((item) => {
            const current = currentById.get(item.id);
            if (!current || current.stock < 1 || !Number.isInteger(item.quantity) || item.quantity < 1) return [];
            return [{ ...current, quantity: Math.min(item.quantity, current.stock, 10) }];
          });
          setCart(synchronized);
        }
      }
    } catch {
      window.localStorage.removeItem("lpc-cart-v1");
    }

    const params = new URLSearchParams(window.location.search);
    if (params.get("cart") === "open") setCartOpen(true);
    const status = params.get("payment");
    const contactPurchase = params.get("contact") === "1";
    const paymentId = params.get("payment_id") || params.get("collection_id");
    const orderNumber = params.get("order") || params.get("external_reference");
    if (status === "approved") {
      if (!contactPurchase) { setCart([]); window.localStorage.removeItem("lpc-cart-v1"); }
      setPaymentNotice(`¡Gracias! El pago del pedido ${orderNumber || ""} fue confirmado.${contactPurchase ? " Tu contacto será enviado por el canal elegido: correo o TikTok." : ""}`);
    } else if (status === "processing" && paymentId) {
      // Reconcile only legacy purchases. New checkout requests exclusively use Webpay.
      setPaymentNotice("Estamos verificando tu pago con Mercado Pago…");
      fetch(`/api/payments/mercadopago/verify?payment_id=${encodeURIComponent(paymentId)}`)
        .then((response) => response.json())
        .then((result: { confirmed?: boolean; status?: string; orderNumber?: string; stockConflict?: boolean }) => {
          if (result.confirmed) {
            if (!contactPurchase) { setCart([]); window.localStorage.removeItem("lpc-cart-v1"); }
            setPaymentNotice(`¡Gracias! El pago del pedido ${result.orderNumber || orderNumber || ""} fue confirmado.${contactPurchase ? " Tu contacto será enviado por el canal elegido: correo o TikTok." : ""}`);
          } else if (result.stockConflict) {
            setPaymentNotice(`El pago fue aprobado, pero el pedido ${result.orderNumber || orderNumber || ""} necesita revisión de disponibilidad. No vuelvas a pagar; nuestro equipo te contactará.`);
          } else if (result.status === "pending" || result.status === "in_process") {
            setPaymentNotice(`El pago del pedido ${result.orderNumber || orderNumber || ""} está pendiente de confirmación oficial. No vuelvas a pagar.`);
          } else {
            setPaymentNotice("Mercado Pago está actualizando el estado. Te avisaremos por correo cuando llegue la confirmación oficial.");
          }
        })
        .catch(() => setPaymentNotice("No pudimos consultar el estado ahora. El pedido se actualizará con la confirmación oficial de Mercado Pago."));
    } else if (status) {
      const messages: Record<string, string> = {
        processing: "Estamos verificando el estado oficial del pago. No vuelvas a pagar mientras esperamos la confirmación.",
        failed: "El pago no se completó. No se descontó inventario; puedes volver a intentarlo.",
        cancelled: "La transacción fue cancelada. Tu carrito sigue disponible.",
        pending: "Tu pago está pendiente de confirmación oficial.",
        review: "Recibimos la autorización y estamos revisando disponibilidad antes de confirmar el pedido.",
        unavailable: "No fue posible verificar el pago. Contacta al equipo antes de volver a intentarlo.",
      };
      setPaymentNotice(messages[status] || "Estamos procesando la confirmación de tu pago.");
    }
    if (status || params.has("cart")) {
      const cleanUrl = `${window.location.pathname}${window.location.hash}`;
      window.history.replaceState(null, "", cleanUrl);
    }
  }, []);

  useEffect(() => {
    if (toast) {
      const timer = window.setTimeout(() => setToast(""), 2800);
      return () => window.clearTimeout(timer);
    }
  }, [toast]);

  const brands = useMemo(() => [...new Set(products.map((product) => product.brand))].sort((a, b) => a.localeCompare(b, "es")), [products]);
  const families = useMemo(() => [...new Set(products.map((product) => product.family))].sort((a, b) => a.localeCompare(b, "es")), [products]);
  const sizes = useMemo(() => [...new Set(products.map((product) => product.size))].sort((a, b) => a.localeCompare(b, "es", { numeric: true })), [products]);
  const filteredProducts = useMemo(() => {
    const query = search.trim().toLocaleLowerCase("es-CL");
    const filtered = products.filter((product) => {
      const text = `${product.brand} ${product.name} ${product.family}`.toLocaleLowerCase("es-CL");
      return (!query || text.includes(query))
        && (gender === "Todos" || product.gender === gender)
        && (brand === "Todas las marcas" || product.brand === brand)
        && (family === "Todas las familias" || product.family === family)
        && (sizeFilter === "Todos los tamaños" || product.size === sizeFilter)
        && product.price <= maxPrice;
    });
    if (sort === "price-asc") filtered.sort((a, b) => a.price - b.price);
    if (sort === "price-desc") filtered.sort((a, b) => b.price - a.price);
    if (sort === "newest") filtered.sort((a, b) => b.id - a.id);
    return filtered;
  }, [products, search, gender, brand, family, sizeFilter, maxPrice, sort]);

  const featured = useMemo(() => products.filter((product) => product.featured).slice(0, 4), [products]);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = form.fulfillment === "delivery" && subtotal > 0 && subtotal < 120000 ? 3990 : 0;
  const total = subtotal + shipping;

  function updateCart(next: CartLine[]) {
    setCart(next);
    try {
      window.localStorage.setItem("lpc-cart-v1", JSON.stringify(next));
    } catch {
      // El carrito permanece disponible en memoria si el almacenamiento del navegador está lleno.
    }
  }

  function addToCart(product: StoreProduct, buyNow = false) {
    const current = cart.find((item) => item.id === product.id);
    if (current && current.quantity >= Math.min(product.stock, 10)) {
      setToast("Alcanzaste el stock disponible para este perfume.");
      return;
    }
    const next = current
      ? cart.map((item) => item.id === product.id ? { ...item, quantity: item.quantity + 1, stock: product.stock } : item)
      : [...cart, { ...product, quantity: 1 }];
    updateCart(next);
    setToast(`${product.name} se añadió a tu bolsa.`);
    if (buyNow) {
      setCheckoutOpen(true);
      setCartOpen(true);
    }
  }

  function setQuantity(id: number, quantity: number) {
    const next = quantity < 1
      ? cart.filter((item) => item.id !== id)
      : cart.map((item) => item.id === id ? { ...item, quantity: Math.min(quantity, item.stock, 10) } : item);
    updateCart(next);
  }

  function explore(genderFilter?: string) {
    if (genderFilter) setGender(genderFilter);
    setMobileMenuOpen(false);
    document.getElementById("catalogo")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  async function submitOrder(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setCheckoutError("");
    if (!cart.length) return;
    setSubmitting(true);
    try {
      const response = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          paymentProvider: "transbank",
          items: cart.map((item) => ({ productId: item.id, quantity: item.quantity })),
        }),
      });
      const result = await response.json() as { error?: string; provider?: string; url?: string; token?: string };
      if (!response.ok || !result.url) throw new Error(result.error || "No pudimos iniciar el pago. Inténtalo nuevamente.");
      if (result.provider === "transbank" && result.token) {
        const paymentForm = document.createElement("form");
        paymentForm.method = "POST";
        paymentForm.action = result.url;
        paymentForm.style.display = "none";
        const token = document.createElement("input");
        token.type = "hidden";
        token.name = "token_ws";
        token.value = result.token;
        paymentForm.appendChild(token);
        document.body.appendChild(paymentForm);
        paymentForm.submit();
        return;
      }
      throw new Error("Webpay no devolvió los datos necesarios para iniciar el pago. Inténtalo nuevamente.");
    } catch (error) {
      setCheckoutError(error instanceof Error ? error.message : "No pudimos iniciar el pago.");
      setSubmitting(false);
    }
  }

  function resetFilters() {
    setSearch("");
    setGender("Todos");
    setBrand("Todas las marcas");
    setFamily("Todas las familias");
    setSizeFilter("Todos los tamaños");
    setMaxPrice(650000);
    setSort("featured");
    setVisibleCount(12);
  }

  return (
    <main>
      <div className="announcement-bar"><span>ENVÍOS ENTRE 14 Y 18 DÍAS</span><span className="announcement-divider">✦</span><span>ENVÍO GRATIS DESDE $120.000 EN TU COMPRA</span></div>
      <header className="site-header">
        <div className="header-inner">
          <button className="mobile-menu-toggle icon-button" type="button" aria-label="Abrir menú" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}><Icon name={mobileMenuOpen ? "close" : "menu"} /></button>
          <Link href="/" className="brand-lockup" aria-label="Luxury Parfum CL, inicio">
            <span className="brand-monogram">LP</span><span className="brand-wordmark"><strong>LUXURY PARFUM</strong><small>CHILE · FRAGANCIAS SELECTAS</small></span>
          </Link>
          <nav className={`main-nav ${mobileMenuOpen ? "is-open" : ""}`} aria-label="Navegación principal">
            <a href="#inicio" onClick={() => setMobileMenuOpen(false)}>Inicio</a>
            <a href="#catalogo" onClick={() => setMobileMenuOpen(false)}>Perfumes</a>
            <a href="#casas" onClick={() => setMobileMenuOpen(false)}>Casas</a>
            <a href="#proveedores" onClick={() => setMobileMenuOpen(false)}>Proveedores</a>
            <a href="#nosotros" onClick={() => setMobileMenuOpen(false)}>Nosotros</a>
          </nav>
          <div className="header-actions">
            <button type="button" className="icon-button search-shortcut" aria-label="Buscar perfumes" onClick={() => explore()}><Icon name="search" /></button>
            <button type="button" className="bag-button" aria-label={`Abrir bolsa, ${cartCount} productos`} onClick={() => { setCartOpen(true); setCheckoutOpen(false); }}><Icon name="bag" /><span>Bolsa</span><b>{cartCount}</b></button>
          </div>
        </div>
      </header>

      {paymentNotice && <div className="payment-notice" role="status"><Icon name="check" size={18} /><span>{paymentNotice}</span><button type="button" onClick={() => setPaymentNotice("")} aria-label="Cerrar aviso"><Icon name="close" size={17} /></button></div>}

      <section className="hero" id="inicio">
        <div className="hero-image" aria-hidden="true"><img src="/images/luxury-parfum-hero.jpg" alt="" /></div>
        <div className="hero-shade" />
        <div className="hero-content page-shell">
          <p className="eyebrow hero-eyebrow"><span className="eyebrow-rule" /> PERFUMERÍA SELECTA · CHILE</p>
          <h1>Tu esencia,<br /><em>tu identidad.</em></h1>
          <p className="hero-description">Fragancias extraordinarias para los momentos que merecen quedarse contigo.</p>
          <button className="button button-gold hero-cta" type="button" onClick={() => explore()}><span>Explorar perfumes</span><Icon name="arrow" size={18} /></button>
          <div className="hero-caption"><span>01 / 03</span><span className="caption-line" /><span>EL ARTE DE PERFUMAR</span></div>
        </div>
        <div className="hero-side-note">SANTIAGO · CHILE <span>38° 00' S / 57° 33' W</span></div>
      </section>

      <div className="benefit-strip page-shell" aria-label="Beneficios de la tienda">
        <div className="benefit-item"><span className="benefit-icon">✦</span><div><strong>Originalidad garantizada</strong><small>Selección con procedencia verificada</small></div></div>
        <div className="benefit-item"><span className="benefit-icon">⌁</span><div><strong>Envíos entre 14 y 18 días</strong><small>Gratis desde $120.000 en Chile</small></div></div>
        <div className="benefit-item"><span className="benefit-icon">◇</span><div><strong>Pago protegido</strong><small>Webpay Plus · Transbank</small></div></div>
        <div className="benefit-item"><span className="benefit-icon">♡</span><div><strong>Atención personal</strong><small>Te ayudamos a elegir</small></div></div>
      </div>

      <section className="featured-section page-shell" id="seleccion">
        <div className="section-heading">
          <div><p className="eyebrow"><span className="eyebrow-rule" /> CURADURÍA DE LA CASA</p><h2>Una selección <em>inolvidable</em></h2></div>
          <button className="text-link" type="button" onClick={() => explore()}>Ver colección completa <Icon name="arrow" size={17} /></button>
        </div>
        <div className="product-grid featured-grid">
          {featured.map((product) => <ProductCard key={product.id} product={product} onAdd={addToCart} onBuyNow={(item) => addToCart(item, true)} onQuickView={setQuickProduct} />)}
        </div>
      </section>

      <section className="category-section" id="casas">
        <div className="page-shell">
          <div className="section-heading category-heading"><div><p className="eyebrow"><span className="eyebrow-rule" /> ENCUENTRA TU FAMILIA</p><h2>El perfume <em>eres tú</em></h2></div><p className="section-intro">Tres formas de comenzar a descubrir una fragancia que hable por ti.</p></div>
          <div className="category-grid">
            <button className="category-tile category-women" type="button" onClick={() => explore("Mujer")}><span className="category-index">01 — PARA ELLA</span><span className="category-name">Notas que<br /><em>seducen.</em></span><span className="category-action">Descubrir <Icon name="arrow" size={16} /></span></button>
            <button className="category-tile category-men" type="button" onClick={() => explore("Hombre")}><span className="category-index">02 — PARA ÉL</span><span className="category-name">Carácter<br /><em>inolvidable.</em></span><span className="category-action">Descubrir <Icon name="arrow" size={16} /></span></button>
            <button className="category-tile category-unisex" type="button" onClick={() => explore("Unisex")}><span className="category-index">03 — SIN ETIQUETAS</span><span className="category-name">A tu manera,<br /><em>siempre.</em></span><span className="category-action">Descubrir <Icon name="arrow" size={16} /></span></button>
          </div>
        </div>
      </section>

      <section className="catalog-section page-shell" id="catalogo">
        <div className="section-heading catalog-heading"><div><p className="eyebrow"><span className="eyebrow-rule" /> COLECCIÓN COMPLETA</p><h2>Encuentra tu <em>fragancia</em></h2></div><span className="catalog-total">{filteredProducts.length} aromas seleccionados</span></div>
        <div className="catalog-toolbar">
          <label className="catalog-search"><Icon name="search" size={19} /><input type="search" placeholder="Busca por nombre, marca o acorde..." value={search} onChange={(event) => { setSearch(event.target.value); setVisibleCount(12); }} /><span>⌘ K</span></label>
          <div className="catalog-sort"><label htmlFor="sort-products">Ordenar por</label><select id="sort-products" value={sort} onChange={(event) => setSort(event.target.value)}><option value="featured">Recomendados</option><option value="price-asc">Precio: menor a mayor</option><option value="price-desc">Precio: mayor a menor</option><option value="newest">Novedades</option></select></div>
        </div>
        <div className="filter-row">
          <label className="filter-select"><span>Género</span><select value={gender} onChange={(event) => setGender(event.target.value)}><option>Todos</option><option>Mujer</option><option>Hombre</option><option>Unisex</option></select></label>
          <label className="filter-select"><span>Marca</span><select value={brand} onChange={(event) => setBrand(event.target.value)}><option>Todas las marcas</option>{brands.map((item) => <option key={item}>{item}</option>)}</select></label>
          <label className="filter-select"><span>Familia olfativa</span><select value={family} onChange={(event) => setFamily(event.target.value)}><option>Todas las familias</option>{families.map((item) => <option key={item}>{item}</option>)}</select></label>
          <label className="filter-select"><span>Tamaño</span><select value={sizeFilter} onChange={(event) => setSizeFilter(event.target.value)}><option>Todos los tamaños</option>{sizes.map((item) => <option key={item}>{item === "S/D" ? "Por confirmar" : item}</option>)}</select></label>
          <label className="price-filter"><span>Hasta <strong>{currency(maxPrice)}</strong></span><input type="range" min="34000" max="650000" step="10000" value={maxPrice} onChange={(event) => setMaxPrice(Number(event.target.value))} /></label>
          <button type="button" className="reset-filters" onClick={resetFilters}>Limpiar filtros</button>
        </div>
        <div className="active-filter-row">
          {gender !== "Todos" && <button type="button" onClick={() => setGender("Todos")}>{gender} <Icon name="close" size={13} /></button>}
          {brand !== "Todas las marcas" && <button type="button" onClick={() => setBrand("Todas las marcas")}>{brand} <Icon name="close" size={13} /></button>}
          {search && <button type="button" onClick={() => setSearch("")}>“{search}” <Icon name="close" size={13} /></button>}
        </div>
        {filteredProducts.length ? <div className="product-grid catalog-grid">
          {filteredProducts.slice(0, visibleCount).map((product) => <ProductCard key={product.id} product={product} onAdd={addToCart} onBuyNow={(item) => addToCart(item, true)} onQuickView={setQuickProduct} />)}
        </div> : <div className="empty-catalog"><span>✧</span><h3>No encontramos esa fragancia</h3><p>Prueba con otra marca o limpia los filtros para explorar la colección completa.</p><button type="button" className="button button-dark" onClick={resetFilters}>Ver todos los perfumes</button></div>}
        {filteredProducts.length > visibleCount && <div className="load-more-wrap"><button type="button" className="button button-outline" onClick={() => setVisibleCount((count) => count + 12)}>Mostrar más perfumes <span>({filteredProducts.length - visibleCount} restantes)</span></button></div>}
      </section>

      <section className="brand-marquee" aria-label="Marcas de la colección"><div className="page-shell"><span className="eyebrow">CASAS QUE NOS INSPIRAN</span><div className="brand-list"><span>BURBERRY</span><span>DIOR</span><span>CREED</span><span>VERSACE</span><span>VALENTINO</span><span>XERJOFF</span><span>TOM FORD</span></div></div></section>

      <SupplierShop suppliers={suppliers} />

      <section className="promise-section" id="nosotros"><div className="page-shell promise-inner"><div className="promise-symbol">✦</div><p className="eyebrow">LUXURY PARFUM CL · NUESTRA PROMESA</p><h2>El lujo está en elegir<br /><em>lo que te representa.</em></h2><p>Creemos que un perfume no se lleva: se recuerda. Por eso seleccionamos fragancias originales y cuidamos cada detalle, desde la primera nota hasta que llega a tus manos.</p><button type="button" className="button button-light" onClick={() => explore()}>Encuentra tu próxima esencia <Icon name="arrow" size={17} /></button></div></section>

      <section className="faq-section page-shell" id="preguntas"><div className="faq-heading"><p className="eyebrow"><span className="eyebrow-rule" /> CONFIANZA EN CADA NOTA</p><h2>Preguntas <em>frecuentes</em></h2><p>Todo lo que necesitas saber antes de elegir tu próxima fragancia.</p></div><div className="faq-list">
        <details><summary>¿Los perfumes son originales?<span>+</span></summary><p>Trabajamos con selección de perfumería de marca y cuidamos su procedencia. Si necesitas información de una referencia específica, escríbenos antes de comprar.</p></details>
        <details><summary>¿Cuánto demora y cuánto cuesta el envío?<span>+</span></summary><p>El envío de los perfumes demora entre 14 y 18 días desde la confirmación del pago. El despacho a domicilio cuesta $3.990 y es gratis desde $120.000. La cobertura se coordina según comuna y región.</p></details>
        <details><summary>¿Cómo recibo el contacto de un proveedor?<span>+</span></summary><p>Los contactos son enviados a tu correo electrónico o por TikTok después de confirmar la compra. Puedes elegir el canal al comprar; para TikTok, indica tu usuario y activa tus mensajes directos. La entrega por TikTok es manual. La compra incluye el contacto, no productos físicos, y no tiene costo de despacho. Si el precio está por confirmar, tu solicitud se guarda sin generar un cobro.</p></details>
        <details><summary>¿Puedo retirar mi pedido?<span>+</span></summary><p>El retiro está disponible previa coordinación y confirmación con nuestro equipo. No se mostrará una dirección hasta confirmar el punto de entrega.</p></details>
        <details><summary>¿Qué medios de pago aceptan?<span>+</span></summary><p>Aceptamos tarjetas de débito y crédito exclusivamente mediante Webpay Plus de Transbank. El pago se realiza en el sitio oficial de Webpay; nunca almacenamos datos de tarjetas.</p></details>
        <details><summary>¿Cuál es la política de cambios?<span>+</span></summary><p>Por tratarse de perfumería, los cambios deben solicitarse con el producto sellado y dentro del plazo legal aplicable. Escríbenos para revisar tu caso y consultar la política vigente antes de comprar.</p></details>
      </div></section>

      <section className="trust-footer-band"><div className="page-shell trust-band-inner"><div><span className="trust-seal">✓</span><span><strong>Compra protegida</strong><small>Tus datos viajan cifrados</small></span></div><div><span className="trust-seal">✦</span><span><strong>Fragancias selectas</strong><small>Calidad y procedencia cuidada</small></span></div><div><span className="trust-seal">⌁</span><span><strong>Atención cercana</strong><small>Estamos para ayudarte</small></span></div></div></section>

      <footer className="site-footer"><div className="page-shell"><div className="footer-main"><div className="footer-brand"><Link href="/" className="brand-lockup"><span className="brand-monogram">LP</span><span className="brand-wordmark"><strong>LUXURY PARFUM</strong><small>CHILE · FRAGANCIAS SELECTAS</small></span></Link><p>Una fragancia extraordinaria.<br />Una forma de ser inolvidable.</p><div className="social-links"><a href="https://www.instagram.com/luxuryparfumcl/" target="_blank" rel="noreferrer" aria-label="Instagram Luxury Parfum CL">ig</a><a href="https://www.tiktok.com/@luxuryparfumcl" target="_blank" rel="noreferrer" aria-label="TikTok Luxury Parfum CL">tk</a></div></div><div className="footer-column"><h3>EXPLORA</h3><a href="#catalogo">Perfumes</a><a href="#casas">Para ella · para él · unisex</a><a href="#proveedores">Proveedores</a><a href="/admin">Panel de administración</a></div><div className="footer-column"><h3>TE ACOMPAÑAMOS</h3><a href="#preguntas">Preguntas frecuentes</a><a href="#preguntas">Despachos y retiros</a><a href="#preguntas">Cambios y devoluciones</a><a href="https://wa.me/?text=Hola%2C%20necesito%20ayuda%20con%20un%20perfume" target="_blank" rel="noreferrer">Contáctanos por WhatsApp</a></div><div className="footer-newsletter"><span className="eyebrow">UNA NOTA PARA TI</span><h3>Un mundo de aromas,<br /><em>en tu correo.</em></h3><p>Próximamente, novedades y lanzamientos seleccionados.</p><span className="footer-newsletter-note">PAGOS SEGUROS · ATENCIÓN DESDE CHILE</span></div></div><div className="footer-bottom"><span>© {new Date().getFullYear()} LUXURY PARFUM CL · SANTIAGO, CHILE</span><span>HECHO CON INTENCIÓN <b>✦</b></span><a href="mailto:contacto@luxuryparfum.cl">contacto@luxuryparfum.cl</a></div></div></footer>

      <a className="whatsapp-float" href="https://wa.me/?text=Hola%2C%20quiero%20asesor%C3%ADa%20sobre%20un%20perfume" target="_blank" rel="noreferrer" aria-label="Consultar por WhatsApp"><span>✆</span><small>¿Te ayudamos?</small></a>
      {toast && <div className="toast-message" role="status"><Icon name="check" size={17} />{toast}</div>}

      {quickProduct && <div className="modal-backdrop" role="presentation" onClick={() => setQuickProduct(null)}><div className="quick-modal" role="dialog" aria-modal="true" aria-label={`Detalles de ${quickProduct.name}`} onClick={(event) => event.stopPropagation()}><button className="modal-close icon-button" type="button" aria-label="Cerrar" onClick={() => setQuickProduct(null)}><Icon name="close" /></button><div className="quick-image"><PerfumePhoto product={quickProduct} /></div><div className="quick-content"><p className="eyebrow">{quickProduct.brand}</p><h2>{quickProduct.name}</h2><p className="quick-size">{quickProduct.size} · {quickProduct.gender}</p><p className="quick-description">{quickProduct.description}</p><div className="quick-notes"><span>FAMILIA OLFATIVA</span><strong>{quickProduct.family}</strong><small>La selección de notas puede variar según la referencia. Consulta con nuestro equipo para asesoría.</small></div><div className="quick-price"><strong>{currency(quickProduct.price)}</strong><del>{currency(quickProduct.retailPrice)}</del></div><div className="quick-buttons"><button className="button button-dark" type="button" disabled={quickProduct.stock < 1} onClick={() => addToCart(quickProduct)}>Añadir a la bolsa <Icon name="bag" size={17} /></button><Link className="button button-outline" href={`/perfumes/${quickProduct.slug}`}>Ver ficha completa <Icon name="arrow" size={16} /></Link></div><p className="secure-caption">✦ Pago seguro · Envío entre 14 y 18 días</p></div></div></div>}

      {cartOpen && <div className="drawer-backdrop" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && setCartOpen(false)}><aside className="cart-drawer" aria-label={checkoutOpen ? "Finalizar compra" : "Tu bolsa de compras"}><div className="drawer-header"><div><span className="eyebrow">LUXURY PARFUM CL</span><h2>{checkoutOpen ? "Finaliza tu compra" : "Tu bolsa"} <small>({cartCount})</small></h2></div><button className="icon-button" type="button" aria-label="Cerrar bolsa" onClick={() => setCartOpen(false)}><Icon name="close" /></button></div>
        {!checkoutOpen ? <>{cart.length ? <><div className="cart-lines">{cart.map((item) => <article className="cart-line" key={item.id}><PerfumePhoto product={item} className="cart-perfume-photo" /><div className="cart-line-copy"><span className="product-brand">{item.brand}</span><strong>{item.name}</strong><small>{item.size}</small><span className="cart-line-price">{currency(item.price * item.quantity)}</span><div className="quantity-control"><button type="button" aria-label="Disminuir cantidad" onClick={() => setQuantity(item.id, item.quantity - 1)}><Icon name="minus" size={14} /></button><span>{item.quantity}</span><button type="button" aria-label="Aumentar cantidad" disabled={item.quantity >= Math.min(item.stock, 10)} onClick={() => setQuantity(item.id, item.quantity + 1)}><Icon name="plus" size={14} /></button></div></div><button className="remove-line" type="button" onClick={() => setQuantity(item.id, 0)}>Eliminar</button></article>)}</div><div className="cart-bottom"><p className="shipping-time-note">Envío de perfumes: <strong>entre 14 y 18 días</strong> desde la confirmación del pago.</p><div className="shipping-progress">{subtotal >= 120000 ? <><span>✦</span> Tu compra tiene despacho gratis</> : <><span>✧</span> Te faltan <strong>{currency(120000 - subtotal)}</strong> para despacho gratis</>}<div className="progress-track"><i style={{ width: `${Math.min((subtotal / 120000) * 100, 100)}%` }} /></div></div><div className="cart-total-row"><span>Subtotal</span><strong>{currency(subtotal)}</strong></div><div className="cart-total-row"><span>Despacho</span><strong>{shipping ? currency(shipping) : "A calcular"}</strong></div><div className="cart-total-row cart-grand-total"><span>Total estimado</span><strong>{currency(subtotal + (form.fulfillment === "pickup" ? 0 : shipping))}</strong></div><button className="button button-dark checkout-button" type="button" onClick={() => { setCheckoutOpen(true); setCheckoutError(""); }}>Continuar al pago <Icon name="arrow" size={18} /></button><p className="cart-security">◇ Pago seguro · Sin almacenamiento de tarjetas</p></div></> : <div className="cart-empty"><span>✧</span><h3>Tu próxima esencia<br />te está esperando.</h3><p>Explora nuestra selección de perfumes originales.</p><button className="button button-dark" type="button" onClick={() => { setCartOpen(false); explore(); }}>Explorar perfumes</button></div>}</>
        : <form className="checkout-form" onSubmit={submitOrder}><button type="button" className="back-to-cart" onClick={() => setCheckoutOpen(false)}>← Volver a la bolsa</button><div className="checkout-summary"><span>{cartCount} {cartCount === 1 ? "artículo" : "artículos"}</span><strong>{currency(total)}</strong></div><label>Nombre y apellido<input required minLength={2} maxLength={120} autoComplete="name" value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} /></label><div className="checkout-form-row"><label>Correo electrónico<input type="email" required autoComplete="email" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} /></label><label>Teléfono<input type="tel" required minLength={6} autoComplete="tel" placeholder="+56 9 1234 5678" value={form.phone} onChange={(event) => setForm({ ...form, phone: event.target.value })} /></label></div><fieldset className="fulfillment-field"><legend>¿Cómo recibes tu pedido?</legend><label className={`choice-row ${form.fulfillment === "delivery" ? "is-selected" : ""}`}><input type="radio" name="fulfillment" value="delivery" checked={form.fulfillment === "delivery"} onChange={() => setForm({ ...form, fulfillment: "delivery" })} /><span><strong>Despacho a domicilio</strong><small>Entrega entre 14 y 18 días · Gratis desde $120.000</small></span></label><label className={`choice-row ${form.fulfillment === "pickup" ? "is-selected" : ""}`}><input type="radio" name="fulfillment" value="pickup" checked={form.fulfillment === "pickup"} onChange={() => setForm({ ...form, fulfillment: "pickup" })} /><span><strong>Retiro coordinado</strong><small>Sin costo · punto de entrega por confirmar</small></span></label></fieldset>{form.fulfillment === "delivery" && <div className="checkout-address"><label>Dirección<input required autoComplete="street-address" value={form.address} onChange={(event) => setForm({ ...form, address: event.target.value })} /></label><div className="checkout-form-row"><label>Comuna<input required value={form.comuna} onChange={(event) => setForm({ ...form, comuna: event.target.value })} /></label><label>Región<input required value={form.region} onChange={(event) => setForm({ ...form, region: event.target.value })} /></label></div></div>}<WebpayPaymentMethod /><label>Nota para tu pedido <span className="optional-label">(opcional)</span><textarea rows={2} maxLength={500} value={form.customerNote} onChange={(event) => setForm({ ...form, customerNote: event.target.value })} /></label><div className="checkout-totals"><div><span>Subtotal</span><strong>{currency(subtotal)}</strong></div><div><span>Despacho</span><strong>{shipping ? currency(shipping) : "Sin costo"}</strong></div><div className="checkout-grand"><span>Total a pagar</span><strong>{currency(total)}</strong></div></div>{checkoutError && <p className="checkout-error" role="alert">{checkoutError}</p>}<p className="checkout-privacy">Al continuar, tus datos se utilizarán para procesar este pedido. Los datos de tarjeta se ingresan directamente en la pasarela oficial y nunca se almacenan aquí.</p><button className="button button-dark checkout-button" type="submit" disabled={submitting || cart.length === 0}>{submitting ? "Conectando con Webpay…" : <>Pagar con Webpay <Icon name="arrow" size={18} /></>}</button><p className="cart-security">◇ Conexión cifrada · Confirmación oficial del pago</p></form>}
        </aside></div>}
    </main>
  );
}
