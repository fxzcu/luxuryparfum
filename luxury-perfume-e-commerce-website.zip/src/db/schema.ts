import { sql } from "drizzle-orm";
import { boolean, integer, jsonb, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export type OrderLine = {
  productId: number | null;
  supplierId?: number;
  kind?: "perfume" | "supplier_contact";
  // Snapshot the actual contacts purchased, not just the editable pack offer.
  contactSupplierIds?: number[];
  includedContactNames?: string[];
  slug: string;
  brand: string;
  name: string;
  size: string;
  image: string;
  quantity: number;
  unitPrice: number;
};

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  brand: text("brand").notNull(),
  name: text("name").notNull(),
  size: text("size").notNull(),
  price: integer("price").notNull(),
  retailPrice: integer("retail_price").notNull(),
  stock: integer("stock").notNull().default(8),
  availability: text("availability").notNull().default("E"),
  gender: text("gender").notNull().default("Unisex"),
  family: text("family").notNull().default("Oriental"),
  image: text("image").notNull().default(""),
  description: text("description").notNull(),
  notes: text("notes").array().notNull().default(sql`ARRAY[]::text[]`),
  featured: boolean("featured").notNull().default(false),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const suppliers = pgTable("suppliers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull().default("perfume"),
  logo: text("logo").notNull().default(""),
  description: text("description").notNull(),
  brands: text("brands").array().notNull().default(sql`ARRAY[]::text[]`),
  price: integer("price"),
  bundleSupplierIds: integer("bundle_supplier_ids").array().notNull().default(sql`ARRAY[]::integer[]`),
  // Private content: never select this field in public responses.
  contact: text("contact").notNull().default(""),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  items: jsonb("items").$type<OrderLine[]>().notNull(),
  subtotal: integer("subtotal").notNull(),
  shipping: integer("shipping").notNull().default(0),
  total: integer("total").notNull(),
  fulfillment: text("fulfillment").notNull().default("delivery"),
  contactDelivery: text("contact_delivery").notNull().default(""),
  tiktokHandle: text("tiktok_handle").notNull().default(""),
  confirmationEmailSentAt: timestamp("confirmation_email_sent_at", { withTimezone: true }),
  address: text("address").notNull().default(""),
  comuna: text("comuna").notNull().default(""),
  region: text("region").notNull().default(""),
  customerNote: text("customer_note").notNull().default(""),
  paymentProvider: text("payment_provider").notNull(),
  paymentStatus: text("payment_status").notNull().default("pending"),
  paymentReference: text("payment_reference").notNull().default(""),
  status: text("status").notNull().default("pending_payment"),
  shipmentStatus: text("shipment_status").notNull().default("not_started"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const storeRevisions = pgTable("store_revisions", {
  key: text("key").primaryKey(),
  appliedAt: timestamp("applied_at", { withTimezone: true }).notNull().defaultNow(),
});
