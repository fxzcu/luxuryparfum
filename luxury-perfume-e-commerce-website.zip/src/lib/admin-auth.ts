import { createHmac, timingSafeEqual } from "node:crypto";

export const ADMIN_COOKIE = "lpc_admin_session";
const SESSION_DURATION_SECONDS = 7 * 24 * 60 * 60;

function sessionSecret() {
  return process.env.ADMIN_SESSION_SECRET || process.env.ADMIN_PASSWORD || "";
}

function constantTimeEqual(left: string, right: string) {
  const leftBuffer = Buffer.from(left);
  const rightBuffer = Buffer.from(right);
  return leftBuffer.length === rightBuffer.length && timingSafeEqual(leftBuffer, rightBuffer);
}

export function adminPasswordIsValid(value: string) {
  const expected = process.env.ADMIN_PASSWORD;
  return Boolean(expected && value && constantTimeEqual(value, expected));
}

export function createAdminToken() {
  const expiresAt = Math.floor(Date.now() / 1000) + SESSION_DURATION_SECONDS;
  const signature = createHmac("sha256", sessionSecret()).update(String(expiresAt)).digest("base64url");
  return `${expiresAt}.${signature}`;
}

export function isValidAdminToken(token: string | undefined) {
  if (!token || !sessionSecret()) return false;
  const [expiresAt, signature] = token.split(".");
  if (!expiresAt || !signature || !/^\d+$/.test(expiresAt)) return false;
  if (Number(expiresAt) <= Math.floor(Date.now() / 1000)) return false;
  const expected = createHmac("sha256", sessionSecret()).update(expiresAt).digest("base64url");
  return constantTimeEqual(signature, expected);
}

export const ADMIN_SESSION_MAX_AGE = SESSION_DURATION_SECONDS;
