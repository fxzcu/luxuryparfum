import { createHash } from "node:crypto";
import { and, asc, count, desc, eq, inArray, like, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { products, storeRevisions } from "@/db/schema";
import { catalogSeeds } from "@/lib/catalog-data";
import { PERFUME_PRICE_STEP } from "@/lib/perfume-pricing";
import originalPhotos from "@/lib/perfume-photos.json";

export const SHIPPING_THRESHOLD = 120_000;
export const SHIPPING_FEE = 3_990;
const photoCatalog: Record<string, { image: string }> = originalPhotos;
const photoRevision = createHash("sha256").update(JSON.stringify(Object.keys(photoCatalog).sort())).digest("hex").slice(0, 12);
const genericImages = ["", "/images/perfume-amber.jpg", "/images/perfume-rose.jpg", "/images/perfume-wood.jpg"];
let seedPromise: Promise<void> | null = null;

/** Apply the requested sale-price update once, without changing reference prices or historical orders. */
export async function applyPerfumePriceRounding() {
  return db.transaction(async (tx) => {
    const revision = await tx.insert(storeRevisions)
      .values({ key: "perfume-sale-prices-nearest-1000-v1" })
      .onConflictDoNothing()
      .returning({ key: storeRevisions.key });
    if (!revision.length) return { applied: false, updatedCount: 0 };
    const updated = await tx.update(products).set({
      price: sql<number>`(round(${products.price}::numeric / ${PERFUME_PRICE_STEP}) * ${PERFUME_PRICE_STEP})::integer`,
      updatedAt: new Date(),
    }).where(sql`${products.price} % ${PERFUME_PRICE_STEP} <> 0`).returning({ id: products.id });
    return { applied: true, updatedCount: updated.length };
  });
}

export async function ensureCatalogSeed() {
  if (!seedPromise) seedPromise = (async () => {
    const [result] = await db.select({ total: count() }).from(products);
    if (Number(result?.total ?? 0) === 0) {
      await db.insert(products).values(catalogSeeds.map((product) => ({
        slug: product.slug, brand: product.brand, name: product.name, size: product.size,
        price: product.price, retailPrice: product.retailPrice, stock: product.availability === "V" ? 2 : 8,
        availability: product.availability, gender: product.gender, family: product.family,
        image: photoCatalog[product.slug]?.image ?? "", description: product.description,
        notes: product.notes, featured: product.featured,
      }))).onConflictDoNothing({ target: products.slug });
    }
    await db.transaction(async (tx) => {
      const revision = await tx.insert(storeRevisions).values({ key: `original-product-photos-v2-${photoRevision}` }).onConflictDoNothing().returning({ key: storeRevisions.key });
      if (!revision.length) return;
      const pending = await tx.select({ id: products.id, slug: products.slug, image: products.image }).from(products)
        .where(or(inArray(products.image, genericImages), like(products.image, "/images/products/%")));
      for (const product of pending) {
        const image = photoCatalog[product.slug]?.image ?? "";
        if (image === product.image) continue;
        await tx.update(products).set({ image, updatedAt: new Date() }).where(and(eq(products.id, product.id), eq(products.image, product.image)));
      }
    });
    await applyPerfumePriceRounding();
  })().catch((error: unknown) => { seedPromise = null; throw error; });
  await seedPromise;
}

const publicProductFields = {
  id: products.id, slug: products.slug, brand: products.brand, name: products.name, size: products.size,
  price: products.price, retailPrice: products.retailPrice, stock: products.stock, availability: products.availability,
  gender: products.gender, family: products.family, image: products.image, description: products.description,
  notes: products.notes, featured: products.featured,
};

export async function getPublicProducts() {
  await ensureCatalogSeed();
  return db.select(publicProductFields).from(products).where(eq(products.active, true)).orderBy(desc(products.featured), desc(sql`${products.image} <> ''`), asc(products.brand), asc(products.name));
}

export async function getPublicProductBySlug(slug: string) {
  await ensureCatalogSeed();
  const [product] = await db.select(publicProductFields).from(products).where(and(eq(products.slug, slug), eq(products.active, true))).limit(1);
  return product ?? null;
}
