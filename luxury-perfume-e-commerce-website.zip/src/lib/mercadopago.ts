import { eq } from "drizzle-orm";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { confirmOrderByNumber } from "@/lib/orders";

export type MercadoPagoPayment = {
  id?: number | string;
  status?: string;
  external_reference?: string;
  transaction_amount?: number;
  currency_id?: string;
};

export async function fetchMercadoPagoPayment(paymentId: string): Promise<MercadoPagoPayment | null> {
  const accessToken = process.env.MERCADOPAGO_ACCESS_TOKEN;
  if (!accessToken || !/^\d{1,24}$/.test(paymentId)) return null;
  const response = await fetch(`https://api.mercadopago.com/v1/payments/${encodeURIComponent(paymentId)}`, {
    headers: { Authorization: `Bearer ${accessToken}` },
    signal: AbortSignal.timeout(15_000),
    cache: "no-store",
  });
  if (!response.ok) return null;
  return (await response.json()) as MercadoPagoPayment;
}

export async function confirmMercadoPagoPayment(payment: MercadoPagoPayment) {
  const orderNumber = payment.external_reference;
  if (!orderNumber || payment.status !== "approved" || payment.currency_id !== "CLP") {
    return { confirmed: false, newlyConfirmed: false, stockConflict: false };
  }

  const [order] = await db
    .select({ total: orders.total, paymentProvider: orders.paymentProvider, paymentStatus: orders.paymentStatus })
    .from(orders)
    .where(eq(orders.orderNumber, orderNumber))
    .limit(1);
  if (!order || order.paymentProvider !== "mercadopago" || Number(payment.transaction_amount) !== order.total) {
    return { confirmed: false, newlyConfirmed: false, stockConflict: false };
  }

  return confirmOrderByNumber(orderNumber, String(payment.id ?? "mercadopago"));
}
