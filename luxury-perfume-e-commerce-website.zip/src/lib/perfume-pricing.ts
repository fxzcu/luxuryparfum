/** Perfume sale prices use the nearest CLP 1,000; halfway values round up. */
export const PERFUME_PRICE_STEP = 1_000;

export function roundPerfumePrice(price: number): number {
  if (!Number.isSafeInteger(price) || price < 0) {
    throw new RangeError("El precio del perfume debe ser un entero no negativo en CLP.");
  }
  const rounded = Math.round(price / PERFUME_PRICE_STEP) * PERFUME_PRICE_STEP;
  if (!Number.isSafeInteger(rounded)) throw new RangeError("El precio redondeado excede el rango permitido.");
  return rounded;
}
