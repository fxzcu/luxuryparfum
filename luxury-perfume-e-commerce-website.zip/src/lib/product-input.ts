import type { products } from "@/db/schema";

type ExistingProduct = typeof products.$inferSelect;
export type ProductInput = Omit<typeof products.$inferInsert, "id" | "createdAt">;

type ProductPayload = Record<string, unknown>;

function textValue(value: unknown, fallback: string, maxLength: number) {
  return typeof value === "string" ? value.trim().slice(0, maxLength) : fallback;
}

function integerValue(value: unknown, fallback: number) {
  if (value === undefined || value === null || value === "") return fallback;
  const number = Number(value);
  return Number.isSafeInteger(number) ? number : Number.NaN;
}

function makeSlug(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export function normalizeProductInput(payload: ProductPayload, existing?: ExistingProduct): ProductInput | null {
  const brand = textValue(payload.brand, existing?.brand ?? "", 100);
  const name = textValue(payload.name, existing?.name ?? "", 160);
  const size = textValue(payload.size, existing?.size ?? "", 40);
  const price = integerValue(payload.price, existing?.price ?? Number.NaN);
  const retailPrice = integerValue(payload.retailPrice, existing?.retailPrice ?? price);
  const stock = integerValue(payload.stock, existing?.stock ?? 8);
  const genderValue = textValue(payload.gender, existing?.gender ?? "Unisex", 30);
  const gender = ["Mujer", "Hombre", "Unisex"].includes(genderValue) ? genderValue : "Unisex";
  const family = textValue(payload.family, existing?.family ?? "Aromática", 60);
  const image = textValue(payload.image, existing?.image ?? "", 500);
  const description = textValue(payload.description, existing?.description ?? `Una selección de ${brand}, presentada en ${size}.`, 1200);
  const notesValue = payload.notes;
  const notes = Array.isArray(notesValue)
    ? notesValue.filter((item): item is string => typeof item === "string").map((item) => item.trim().slice(0, 80)).filter(Boolean).slice(0, 8)
    : existing?.notes ?? [];
  const availabilityValue = textValue(payload.availability, existing?.availability ?? "E", 8);
  const featured = typeof payload.featured === "boolean" ? payload.featured : existing?.featured ?? false;
  const active = typeof payload.active === "boolean" ? payload.active : existing?.active ?? true;
  const safeImage = !image || (image.startsWith("/") && !image.startsWith("//")) || image.startsWith("https://");

  if (!brand || !name || !size || !family || !safeImage) return null;
  if (!Number.isSafeInteger(price) || price < 0 || price > 100_000_000) return null;
  if (!Number.isSafeInteger(retailPrice) || retailPrice < 0 || retailPrice > 100_000_000) return null;
  if (!Number.isSafeInteger(stock) || stock < 0 || stock > 1_000_000) return null;

  return {
    slug: makeSlug(`${brand}-${name}-${size}`),
    brand,
    name,
    size,
    price,
    retailPrice,
    stock,
    availability: availabilityValue === "V" ? "V" : "E",
    gender,
    family,
    image,
    description,
    notes,
    featured,
    active,
    updatedAt: new Date(),
  };
}
