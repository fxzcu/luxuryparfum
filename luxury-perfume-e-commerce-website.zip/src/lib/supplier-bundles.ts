export const BUNDLE_CATEGORIES = ["technology", "perfume", "wholesale"] as const;

export type ContactReference = { id: number; name: string; category: string };
export type ContactAvailability = ContactReference & {
  price: number | null;
  active: boolean;
  hasContact: boolean;
};

type OfferReference = { id: number; category: string; bundleSupplierIds: number[] };

/** Resolve only server-selected members. Never trust member IDs from checkout input. */
export function resolveOfferContacts(offer: OfferReference, records: ContactAvailability[]) {
  const isBundle = offer.category === "bundle";
  const ids = isBundle ? offer.bundleSupplierIds : [offer.id];
  const byId = new Map(records.map((record) => [record.id, record]));
  const members = ids.flatMap((id) => byId.has(id) ? [byId.get(id)!] : []);
  const valid = isBundle
    ? ids.length === 3 && new Set(ids).size === 3 && members.length === 3
      && BUNDLE_CATEGORIES.every((category) => members.filter((member) => member.category === category).length === 1)
      && !ids.includes(offer.id)
    : members.length === 1 && members[0].category !== "bundle";
  const contacts: ContactReference[] = members.map(({ id, name, category }) => ({ id, name, category }));
  const individualTotal = valid && members.every((member) => member.active && member.price !== null && member.price > 0)
    ? members.reduce((sum, member) => sum + member.price!, 0)
    : null;
  return { contacts, valid, ready: valid && members.every((member) => member.active && member.hasContact), individualTotal };
}
