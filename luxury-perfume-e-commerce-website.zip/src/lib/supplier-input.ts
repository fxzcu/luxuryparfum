import { inArray } from "drizzle-orm";
import { db } from "@/db";
import { suppliers } from "@/db/schema";
import { BUNDLE_CATEGORIES } from "@/lib/supplier-bundles";

type Supplier = typeof suppliers.$inferSelect;
export function normalizeSupplierInput(body: Record<string, unknown>, existing?: Supplier) {
  if (!body || typeof body !== "object" || Array.isArray(body)) return null;
  const text = (key: string, fallback: string, max: number) => typeof body[key] === "string" ? (body[key] as string).trim().slice(0, max) : fallback;
  const name = text("name", existing?.name ?? "", 120);
  const logo = text("logo", existing?.logo ?? "", 500);
  const description = text("description", existing?.description ?? "", 1200);
  const category = text("category", existing?.category ?? "perfume", 30);
  const contact = category === "bundle" ? "" : text("contact", existing?.contact ?? "", 4000);
  const price = body.price === undefined ? existing?.price ?? null : body.price === null || body.price === "" ? null : Number(body.price);
  const brands = Array.isArray(body.brands) ? body.brands.filter((item): item is string => typeof item === "string").map((item) => item.trim().slice(0, 80)).filter(Boolean).slice(0, 10) : existing?.brands ?? [];
  if (!name || !description || ![...BUNDLE_CATEGORIES, "bundle"].includes(category)) return null;
  if (logo && !(logo.startsWith("/") && !logo.startsWith("//")) && !logo.startsWith("https://")) return null;
  if (price !== null && (!Number.isSafeInteger(price) || price < 1 || price > 100_000_000)) return null;
  const rawIds = body.bundleSupplierIds === undefined ? existing?.bundleSupplierIds ?? [] : body.bundleSupplierIds;
  const bundleSupplierIds = category === "bundle" ? rawIds : [];
  if (!Array.isArray(bundleSupplierIds) || bundleSupplierIds.some((id) => typeof id !== "number" || !Number.isSafeInteger(id) || id < 1)) return null;
  if (category === "bundle" && (bundleSupplierIds.length !== 3 || new Set(bundleSupplierIds).size !== 3 || bundleSupplierIds.includes(existing?.id))) return null;
  return { name, category, logo, description, brands, price, contact, bundleSupplierIds: bundleSupplierIds as number[], active: typeof body.active === "boolean" ? body.active : existing?.active ?? true, updatedAt: new Date() };
}

export async function validateSupplierBundle(category: string, ids: number[]) {
  if (category !== "bundle") return true;
  if (ids.length !== 3 || new Set(ids).size !== 3) return false;
  const members = await db.select({ category: suppliers.category }).from(suppliers).where(inArray(suppliers.id, ids));
  return members.length === 3 && BUNDLE_CATEGORIES.every((expected) => members.filter((member) => member.category === expected).length === 1);
}
