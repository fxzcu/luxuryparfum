import { asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { storeRevisions, suppliers } from "@/db/schema";
import { resolveOfferContacts } from "@/lib/supplier-bundles";

const INITIAL_OFFERS = [
  { name: "Proveedor de tecnología", category: "technology", price: 11990, description: "Adquiere el contacto de un proveedor de tecnología para consultar su catálogo, accesorios y condiciones de compra. Un punto de partida para tu próximo negocio.", brands: ["Tecnología", "Accesorios", "Emprendimiento"] },
  { name: "Proveedor de perfumes", category: "perfume", price: 10990, description: "Accede al contacto de un proveedor de perfumes y consulta directamente su selección de fragancias, disponibilidad y condiciones de compra.", brands: ["Perfumería", "Fragancias", "Compra directa"] },
  { name: "Proveedor de perfumes al por mayor", category: "wholesale", price: 12990, description: "Obtén el contacto de un proveedor de perfumes mayorista para consultar compras por volumen, cantidades mínimas y condiciones para tu emprendimiento.", brands: ["Venta mayorista", "Compras por volumen", "Reventa"] },
];

let initialized: Promise<void> | null = null;
export async function ensureSupplierOffers() {
  if (!initialized) initialized = db.transaction(async (tx) => {
    const initial = await tx.insert(storeRevisions).values({ key: "supplier-contact-offers-v1" }).onConflictDoNothing().returning({ key: storeRevisions.key });
    if (initial.length) {
      await tx.delete(suppliers);
      await tx.insert(suppliers).values(INITIAL_OFFERS.map((offer) => ({ ...offer, contact: "", active: true })));
    }
    // Apply this requested price update once. Preserve later admin edits and all private contacts.
    const pricing = await tx.insert(storeRevisions).values({ key: "supplier-prices-and-three-contact-pack-v2" }).onConflictDoNothing().returning({ key: storeRevisions.key });
    if (!pricing.length) return;
    const memberIds: number[] = [];
    for (const offer of INITIAL_OFFERS) {
      const [existing] = await tx.select({ id: suppliers.id }).from(suppliers).where(eq(suppliers.category, offer.category)).orderBy(asc(suppliers.id)).limit(1);
      if (existing) {
        await tx.update(suppliers).set({ price: offer.price, active: true, updatedAt: new Date() }).where(eq(suppliers.id, existing.id));
        memberIds.push(existing.id);
      } else {
        const [created] = await tx.insert(suppliers).values({ ...offer, contact: "", active: true }).returning({ id: suppliers.id });
        memberIds.push(created.id);
      }
    }
    const bundle = {
      name: "Pack de los 3 proveedores",
      category: "bundle",
      price: 19990,
      description: "Amplía tus posibilidades con los tres contactos en una sola compra: tecnología, perfumes y perfumes al por mayor. Recíbelos juntos en tu correo electrónico o por TikTok.",
      brands: ["Tecnología", "Perfumes", "Perfumes al por mayor"],
      bundleSupplierIds: memberIds,
      active: true,
      updatedAt: new Date(),
    };
    const [existingBundle] = await tx.select({ id: suppliers.id }).from(suppliers).where(eq(suppliers.category, "bundle")).orderBy(asc(suppliers.id)).limit(1);
    if (existingBundle) await tx.update(suppliers).set(bundle).where(eq(suppliers.id, existingBundle.id));
    else await tx.insert(suppliers).values({ ...bundle, contact: "" });
  }).catch((error: unknown) => { initialized = null; throw error; });
  await initialized;
}

export async function getSupplierOfferRecords() {
  await ensureSupplierOffers();
  // Only availability of private content is selected, not its actual value.
  return db.select({
    id: suppliers.id, name: suppliers.name, category: suppliers.category,
    description: suppliers.description, logo: suppliers.logo, brands: suppliers.brands,
    price: suppliers.price, active: suppliers.active, bundleSupplierIds: suppliers.bundleSupplierIds,
    hasContact: sql<boolean>`length(trim(${suppliers.contact})) > 0`.mapWith(Boolean),
  }).from(suppliers).orderBy(asc(suppliers.id));
}

export async function getPublicSupplierOffers() {
  const records = await getSupplierOfferRecords();
  return records.filter((offer) => offer.active).map((offer) => {
    const resolved = resolveOfferContacts(offer, records);
    return {
      id: offer.id, name: offer.name, category: offer.category, description: offer.description,
      logo: offer.logo, brands: offer.brands, price: offer.price,
      canPurchase: Boolean(offer.price && offer.price > 0 && resolved.ready),
      includedSuppliers: resolved.contacts,
      individualTotal: offer.category === "bundle" ? resolved.individualTotal : null,
    };
  });
}
